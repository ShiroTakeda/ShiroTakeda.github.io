Author:  Shiro Takeda
Maintainer:  Shiro Takeda
Time-stamp:  <2008-03-29 13:32:28 Shiro Takeda>
$id:$
----------------------------------------------------------------

If you use an external command for GAMS-OUTLINE, you need place
gamsolc.exe or gamsperl.pl (perl script) at the proper place.  See the
help description of the variable `gams-ol-external-program'.

* If you use gamsolc.exe:

Put the gamsolc.exe at the place specified by the variable
`gams-ol-external-program'.

* If you use gamsperl.pl:

Put the gamsperl.pl at the place specified by the variable
`gams-ol-external-program' and set the place of perl to the variable
`gams-perl-command'.

