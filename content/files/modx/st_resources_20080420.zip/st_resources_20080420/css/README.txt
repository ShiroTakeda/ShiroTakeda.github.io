Filename:            README.txt
Author:		     Shiro Takeda
Time-stamp:	       <2008-04-20 12:41:21 Shiro Takeda>

--------------------------------------------------------------------------

"style.css" も "menu.css" も "Nicola Lambathakis (banzai) banzai@tattoocms.it"さ
んによって作成された "ax07" というsite templateに含まれていたcssファイルを武田が
手直ししたものです。オリジナルの ax07 は

URI: http://www.tattoocms.it/templates/ax07.html

で入手可能です。

多くの部分を変更したので元のax07とはかなり見た目は異なっています。


http://shirotakeda.org/ では css ファイルも他のページと同様に一つのドキュメント
として管理しています。

cssファイルはtemplateファイルから読み込むようになっているので、templateファイル
の中のcssファイルを表すドキュメントIDを自分の環境に合うように修正する必要があり
ます。

元のtemplateファイルでは

<link href="[~75~]" rel="stylesheet" type="text/css" />
<link href="[~76~]" rel="stylesheet" type="text/css" />

となっていますが、自分の登録した style.css ファイル、menu.css ファイルのドキュメ
ントIDがそれぞれ 80、90 なら上の 75、76 の部分を 80、90に書き換えるということで
す。


--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
