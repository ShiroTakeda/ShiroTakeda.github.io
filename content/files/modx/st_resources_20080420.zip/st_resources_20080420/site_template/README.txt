Filename:            README.txt
Author:		     Shiro Takeda
Time-stamp:	       <2008-04-20 12:44:09 Shiro Takeda>

--------------------------------------------------------------------------

[ファイルの説明]

top_page_en.html	英語トップページ用テンプレート
top_page_ja.html	日本語トップページ用テンプレート
sub_page_en.html	英語サブページ用テンプレート
sub_page_ja.html	日本語サブページ用テンプレート

[解説]

□スタイルファイルについて

どのファイルでも

<link href="[~75~]" rel="stylesheet" type="text/css" />
<link href="[~76~]" rel="stylesheet" type="text/css" />

というタグでスタイルシートを読み込んでいます。私の環境では[~75~]、[~76~] の二つ
のファイルが"style.css"、"menu.css"です。

http://shirotakeda.org/ では css ファイルも他のページと同様に一つのドキュメント
として管理しています。上の部分のドキュメントIDは自分のサイトの状況に合うように修
正する必要があります。

例えば、自分の登録した style.css ファイル、menu.css ファイルのドキュメントIDがそ
れぞれ 80、90 なら上の 75、76 の部分を 80、90に書き換えるということです。


□ Chunkについて

{{xxx}} という命令で様々な chunk を読み込んでいます。それぞれがどのような
chunk かは chunk のフォルダのほうを見てください。


--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
