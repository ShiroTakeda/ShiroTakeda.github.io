Filename:            README.txt
Author:		     Shiro Takeda
Time-stamp:	       <2008-04-20 14:11:24 Shiro Takeda>

--------------------------------------------------------------------------

以下のフォルダには http://shirotakeda.org/ で利用している

* site template
* css ファイル
* chunk

のファイルが含まれています。

snippet_and_plugin.txt は snippetとpluginについての説明です。


--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
