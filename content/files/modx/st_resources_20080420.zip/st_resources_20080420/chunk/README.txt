Filename:            README.txt
Author:		     Shiro Takeda
Time-stamp:	       <2008-04-20 12:29:07 Shiro Takeda>

--------------------------------------------------------------------------

[Chunkの登録方法]

"xxx.chunk"というファイルのchunkを登録するには

「リソース」→「リソース管理」→「チャンク」→「チャンクの作成」とたどり

チャンク名に"xxx"を指定し、チャンクコードに"xxx.chunk"の中身を貼り付けてや
ればよい。

以下では自分で作成したchunkのみをあげています。実際にはこれに加えて site
template ax07 に付属の

ax07
axInner
axInnerRowTpl
axOuter
axParentRow
axRowTpl
news

等のchunkも利用しています。


[ファイルの説明]

"st_accessanalysis.chunk"

  </body>タグの直前にtemplateに読み込まれるchunk。access解析用のコードを書
  いておくためのもの。 

"st_changelist.chunk"

  更新ページで利用しているDittoのtemplate。

"st_changelist_side.chunk"

  左サイドバーで利用しているDittoのtemplate。

"st_footer.chunk"

  footer用のchunk。著作権情報などを書いておくためのもの。

"st_go2top.chunk"

  Pageのトップへ移動するためのchunk。

"st_ContactForm_ja.chunk"

  コンタクトフォーム用のchunk。

"st_ContactFormReport_ja.chunk"

  コンタクトフォームで利用しているeFormのためのtemplate。

"st_PageTOC_end.chunk", "st_PageTOC_pre.chunk", "st_PageTOC_pre_ja.chunk", "st_PageTOC_start.chunk"

  Page TOC Generatorというページの目次を自動生成させるPluginのためのchunk。
			



--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
