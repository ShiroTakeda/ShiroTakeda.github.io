
First-written:       <2011/01/08>
Time-stamp:	       <2011-01-15 04:07:07 >

--------------------------------------------------------------------------

□ 3つのアプローチ

1) Single フォルダ -> 一つずつ解く
2) Approach_1 フォルダ -> 複数同時に解く
3) Approach_2 フォルダ -> 複数同時に解く


□ Approach_1 と Approach_2 の違い．

+ Approach_1 では Approach_1 フォルダを作業フォルダとしてモデルを解く．
+ Approach_2 ではプロセス毎に別の作業フォルダを作成して解く．
+ MPSGE を利用する場合には Approach_2 でないと上手くいかないことがある．


□ プログラムの説明

+ どのアプローチでも outline-sample.gms というプログラムを 10 回解く．


□ 実行方法

+ 各フォルダにある run_scenarios.bat ファイルを実行すればよい．
+ 注: gams.exe に PATH が通っている必要あり．
+ Single のプログラムより Approach_1 & Approach_2 のプログラムの方が圧倒的に速く
  解ける．


□ ファイル

+ runjobs フォルダの中身は Rutherford のウェブサイト http://www.mpsge.org/ から
  ダウンロードしたもの． 



--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
