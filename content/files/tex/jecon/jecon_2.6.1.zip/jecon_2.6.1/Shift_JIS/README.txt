Filename:            README.txt
Author:		     Shiro Takeda
e-mail               <shiro.takeda@gmail.com>
First-written:       <2008/12/22>
Time-stamp:	       <2008-12-22 15:52:49 Shiro Takeda>

--------------------------------------------------------------------------

Shift JIS�R�[�h�ɕϊ������t�@�C���B


--------------------
Local Variables:
mode: indented-text
coding: sjis
fill-column: 80
End:
