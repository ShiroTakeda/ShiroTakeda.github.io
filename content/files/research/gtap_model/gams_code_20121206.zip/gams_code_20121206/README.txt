
Author:		     Shiro Takeda <shiro.takeda@gmail.com>
First-written:       <2006/07/31>
Time-stamp:	     <2012-12-06 19:36:38 >

--------------------------------------------------------------------------------

-------------------------------------------------------
0. Contents
-------------------------------------------------------

1. Requirements.
2. How to do a test simulation.
3. How to do a different simulation.
4. How to do a different simulation with different data.
5. Notes on the program.

-------------------------------------------------------
1. Requirements.
-------------------------------------------------------

To use this program, you must install

+ har2gdx.exe, and
+ gdx2har.exe (and gdxiomh.dll)

If you have not installed these programs, download them from

http://www.mpsge.org/gdxhar/index.html

and put them in the GAMS system directory.

In addition, the GAMS system directory must be in the PATH environmental
variable.  If the GAMS system directory is not included in PATH, you must set it
by Control Panel -> System -> Environmental variables.


-------------------------------------------------------
2. How to do a test simulation
-------------------------------------------------------

[Note] The "top folder" in the explation below indicates the folder where this
README.txt file is placed and "ACORS3X3 folder" indicate ACORS3X3 folder under
the top folder.

You can run a test simulation in the following way.

* To do the test simulation, we use the dataset distributed with RunGTAP5 as an
  example.  If you don't have RunGTAP5, download the demo version of RunGTAP5
  from

 https://www.gtap.agecon.purdue.edu/resources/res_display.asp?RecordID=411

 and install it.

* Copy the following three files

	+ Basedata.har,
	+ Default.prm,
	+ SETS.HAR

  from ACORS3X3 folder under RunGTAP5 folder (for example, if you insalled
  RunGTAP5 at c:\RunGTAP5, then c:\RunGTAP5\ACORS3X3) to ACORS3X3 folder under
  the top folder.

* Execute run_test.bat in ACORS3X3 folder (from the command prompt or by
  clicking the file), then the simulation will start.

* If the test simulation is done without problems, then a file named
  "test_sol.har" will be created in "results" directory under ACORS3X3 folder.
  In that file, percentage change in various variables and EV will be reported.

In this test simulation, we calculate the counter factual equilibrium where

  (1) all tms and txs are set to 1 (i.e. all trade taxes and subsidies are
      removed),
  (2) endowment of mobile endowment commodities are increased by 20%,
  (3) endowment of sluggish endowment commodities are reduced by 10%.


Results derived from this simulation will be as follows:

[Equivalent variation]
EV  	EV
1 SSA	46163.98
2 EU	1434667.38
3 ROW	3327353.75
4 World	4808185.00
Total	9616370.00

[% change in utility]
PC63	pc_u
1 SSA	16.6792
2 EU	19.8752
3 ROW	18.9264

[% change in value of GDP]
PC_V	pc_vgdp
1 SSA	19.4038
2 EU	17.8901
3 ROW	17.5131

[% change in real GDP]
P107	pc_qgdp
1 SSA	17.2694
2 EU	19.8131
3 ROW	19.1102


For comparison, I conducted the same simulation in RunGTAP (gtap.tab ver. 6.2)
using the model ACORS3X3 under the following settings:

* Closure -> Default

* Parameter file -> Default

* Solution method:

	Method = Gragg;
	Steps = 2 4 6;

* Shock list:

	Shock tms(TRAD_COMM,REG,REG) = target% 0 from file tms.shk;
	Shock txs(TRAD_COMM,REG,REG) = target% 0 from file txs.shk;
	Shock qo(ENDWS_COMM,REG) = uniform -10;
	Shock qo(ENDWM_COMM,REG) = uniform 20;


Then, I got the following results:

[Equivalent variation]
EV	(Sim)
SSA	46163.93
EU	1434689.88
ROW	3327389.75
Total	4808243.56

[% change in utility]
u	(Sim)
SSA	16.6791
EU	19.8755
ROW	18.9266

[% change in value of GDP]
vgdp	(Sim)
SSA	19.4041
EU	17.8905
ROW	17.5134

[% change in real GDP]
qgdp	(Sim)	 	 	 
SSA	17.2615
EU	19.8120
ROW	19.1110


These results are almost the same as the results derived from my model although
there are small differences.


-------------------------------------------------------
3. How to do a different simulation.
-------------------------------------------------------

In this section, I explain how to do a different simulation with the same
dataset as the above test simulation.  To do a different simulation, you need to
prepare (at least) the following three files:

[1] Batch file.
[2] Experiment file.
[3] Shock file.

In the test simulation explained above, these files correspond to the following
three files:

run_test.bat
test.exp
test.shk

in ACORS3X3 folder.  In the example below, we assume that three files for this
simulation have the following name.

run_test_alt.bat
test_alt.exp
test_alt.shk

You need to create these files in ACORS3X3 folder (in fact, these files are
already provided).


[1] Batch file (run_test_alt.bat).

In the batch file, you must specify an experiment name.  Suppose that the
experiment name is "test_alt".  Then, you must put the following line in the
run_test_alt.bat.

call ..\run_one_scenario test_alt


[2] Experiment file (test_alt.exp).

An experiment file must has a name of "experiment name" + ".exp".  Thus, in
this example, the experiment file name must be "test_alt.exp".

In this experiment file, we must specify values of various GAMS global
variables.  As an example, please create the file "test_alt.exp" which
contains the following code:

$setglobal gtap_data_ver 5
$setglobal shock_file %exp_name%.shk

$setglobal updated_data_file %exp_name%_upd.har
$setglobal solution_file %exp_name%_sol.har
$setglobal par_file default.prm
$setglobal rordelta 0
$setglobal cls_file default.cls
$setglobal basedata_file basedata.har
$setglobal set_file sets.har
$setglobal main_model_file ..\gtap_model.gms
$setglobal solution_program_file ..\gtap_export_solution.gms
$setglobal update_program_file ..\gtap_update_data.gms
$setglobal bench_rep_only 0
$setglobal clean_up_only 0
$setglobal solver_mcp 1
$setglobal mcp_solver path
$setglobal nlp_solver pathnlp
$setglobal scale_factor 1e-3
$setglobal fl_debug 0
$setglobal appendix_file ..\gtap_app_output.gms


For the meanings of variables, please read the explanation in the first part
of gtap.gms.


[4] Run the different simulation.

If you create three files, you can run the simulation by executing
run_test_alt.bat.  As in the test simulation, the results will go to results
folder under ACORS3X3 folder.


-------------------------------------------------------
4. How to do a different simulation with different data
-------------------------------------------------------

In this section, we explain how to do a different simulation with the
different data.  For example, suppose that you create your own data from GTAP
ver 6 data and that you want to do the same simulation as the test simulation
with the new data.

[1] Copy the new data:

Copy the following three files

	+ Basedata.har,
	+ Default.prm,
	+ SETS.HAR

to new_data folder, i.e. GTAP6 folder under the top folder.

[2] Copy the program files used for the simulation:

Next, copy the following five files from ACORS3X3 folder to GTAP6 folder.

	run_test.bat
	test.exp
	test.shk
	sluggish_factor_default.gms
	default.cls

[3] Modify the content of "sluggish_factor_default.gms":

Modyfiy the content of "sluggish_factor_default.gms" file according to your new
data.  In this file, you must specify the set of sluggish endowment commodities.
For example, if the new data have the three endowment commodities, (Land, Labor,
and Capital) and Land is the sluggish endowment commodity, then you must change
the content of "sluggish_factor_default.gms" to

	es("Land") = yes;

[4] Modify the content of "test.exp":

Finally, you must change the content of test.exp to

	$setglobal gtap_data_ver 6

because the value of "gtap_data_ver" must be 6 if you use GTAP ver 6 data.

[5] Run the simulation:

To run the simulation, execute "run_test.bat".


-------------------------------------------------------
5. Notes on the program.
-------------------------------------------------------

+ The benchmark data and parameters are imported from basedata.har and
  default.prm.  However, the following PARAMETER and SET must be defined by
  yourself.

  The value of RORDELTA (investment allocation binary coefficient)
  The set of sluggish endowment commodities ("es" in this program).

+ You can specify the the value of RORDELTA by assigning the proper value
  to the global variable RORDELTA below and you can specify the SET "es"
  in gtap_set_sluggish.gms file.

+ Parameters for benchmark data and equations are basically represented by upper
  case identifiers and endogenous ariables are basically represented by lower
  case identifiers although there are some exceptions.

+ I tried to replicate the GTAP model as precisely as possible.  However,
  some linearized equations in gtap.tab cannot be intrinsically
  transformed to level form.  These equations include

  GLOBALINV
  PRICGDS
  PRIMFACTPR
  PRIMFACTPRWLD

  In order to create the model completely written in level form, the
  specification of these equations is slightly modified by me.  This means that
  the results from our model do not intrinsically coincide with those from the
  original GTAP model.  The differences in results from two models are ignorable
  when you add only small shocks.  However, an experiment with large shocks may
  generate highly different results.

+ In the appendix of gtap.tab, many variables are defined in order to report
  various effects.  Such variables are omitted in my program except for some
  variables (e.g. vgdp, EV).

+ Explanatory texts for sets, variables, parameters, and equations are directly
  taken from gtap.tab.

+ This code is likely to include bugs, so be careful when you use it.

+ The line like display "com: ..." is added for Editor Emacs. If you are not
  Emacs user, you can delete these lines.




--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
