
Author:		     Shiro Takeda <shiro.takeda@gmail.com>
First-written:       <2006/07/31>
Time-stamp:	     <2012-12-06 19:48:17 >

--------------------------------------------------------------------------------

Lists of experiments:

--------------------------------------------------------------------------------

[run_test.bat]

+ test experiment.
+ See README.txt file in the top folder.
+ In this experiment, we assume
  + all tms and txs are set to 1 (i.e. all trade taxes and subsidies are removed),
  + endowment of mobile endowment commodities are increased by 20%,
  + endowment of sluggish endowment commodities are reduced by 10%.
 

[run_test_alt.bat]

+ test experiment 2.
+ In this experiment, we assume
  + endowment of endowment commodities are increased by 10%
    qo.fx(e,r) = 1.1;


[run_numeraire_shock.bat]

+ Price of pfactwld.fx changes from 1 to 1.1.
+ We must get no change in real variables.


[run_scale_shock.bat]

+ Endowment of endowment commodities are increased by 10%
  + qo.fx(e,r) = 1.1;


[run_scale_shock_homothetic.bat]

+ In this case, homothetic.prm is used for parameter file (instead of default.prm).
  homethetic.prm is parameter setting for homothetic consumer preference (not
  CDE preference).
+ Endowment of endowment commodities are increased by 10%
  + qo.fx(e,r) = 1.1;
+ We must have 10% increase in all real variables.


[run_liberalization_shock.bat]

+ All trade taxes and subsidies are removed.


[run_use_updated_data.bat]

+ Simulation using the updated benchmark data.





--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
