
Author: 	Shiro Takeda
First-written:	<2017/02/10>
Time-stamp:	<2017-04-22 15:51:26 st>
Email: 		shiro.takeda@gmail.com

--------------------------------------------------------------------------

* プログラムの説明

** 説明

このプログラムは、

武田史郎 (2017)「排出量取引と自主的行動によるCO2削減の効果 －応用一般均衡モデル
による分析－」，環境科学会，30(2)，pp.141–149．

のシミュレーションをおこなうためのプログラムです。


** プログラムを実行するのに必要なもの

+ GAMS base module + Solver PATH + Solver MPSGE
+ GAMS本体（GAMS base module）に加えて、PATHとMPSGEの二つのソルバーが必要という
  ことです。


** プログラムの実行方法

プログラムの実行方法

[Step 1]
+ gam.exeのあるフォルダにPATHを通す。

[Step 2]
+ run_scenarios.bat を実行する（ファイルをクリックします）。
+ これで感度分析も含め全てのケースを解きます。

[Step 3]
+ export_excel.bat を実行する
+ これで計算結果が "\results\results_summary.xlsx" に出力されます。

［注］
+ GAMSIDEで japan_model_main_static.gms を実行するのでもモデルを解けますが、その
  場合には、基準ケースしか計算しません。





--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:



