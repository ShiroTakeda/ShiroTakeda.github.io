Filename:            README.txt
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2007/20/19>
Time-stamp:	       <2007-02-19 20:48:50 Shiro Takeda>

$BBh(B 5.10.1 $B@a$K$*$1$k!$(BJohansen method $B$H(B non-linear solution method $B$NHf3S(B
$B$r(B GEMPACK (RunGTAP) $B$G$*$3$J$&$?$a$N%W%m%0%i%`Ey!%(B

----------------------------------
$B%U%!%$%k$N@bL@!%(B
----------------------------------

$B!&(B"23x18.agg"

$B$3$N%U%!%$%k$r(B aggregation scheme $B%U%!%$%k$H$7$F!$(BGTAP 5.4 $B%G!<%?$rE}9g$7(B
$B$F$$$^$9!%E}9g$K$O(B GTAPAggN $B$N(B gtapagg.exe $B$rMxMQ!%ItLg!$CO0h$N(B mapping $B$O0J2<$N(B
$BJ88%$r;2>H!%(B

Kiyota, Kozo (2006)
"An Analysis of the Potential Economic Effects of
Bilateral, Regional, and Multilateral Free Trade.",
RIETI Discussion Paper Series 06-E-027.

$B!&(B"johansen.exp"$B!$(B"euler.exp"$B!$(B"gragg.exp"

$B$=$l$>$l(B Johansen method$B!$(BEuler method$B!$(BGragg method $B$G2r$/:]$N(B experiment
file. $BCf?H$r8+$l$P$I$N$h$&$J@_Dj$G%b%G%k$r2r$$$F$$$k$+$,$o$+$j$^$9!%(B3 $B$D$N(B
$B0c$$$O(B solution method $B$@$1$G$9!%(B


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
