
First-written:	<2015/12/26>
Time-stamp:	<2015-12-26 14:20:09 st>

--------------------------------------------------------------------------

* How to run simulation.

1) Click "run_scenarios.bat" file. This solves all the scenarios.

2) After run_scenarios.bat finishes, click export_excel.bat. This export results
   to "results_summary.xlsx" in the subfolder "results".

[Note] To execute the simulation, GAMS system folder (gams.exe) must be included
in the environmental variable PATH.








--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
