
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:31:37 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ 以下がプログラムのファイルです。
  + ge_sample_dual.gms
  + ge_sample_dual_alt.gms
  + ge_sample_trad.gms
  + ge_zero_h_check.gms
  + ge_zero_h_check_fail.gms
  + ge_walrus_check.gms
  + ge_walrus_check_fail.gms
  + ge_proportional_check.gms
  + ge_proportional_check_fail.gms
  + ge_simulation.gms

+ どのファイルがどのようなプログラムかは解説書を読んでください。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
