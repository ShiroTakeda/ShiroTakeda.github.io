
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:43:23 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ 以下がプログラムのファイルです。
  + calibration_example.gms
  + calibration_example_CD.gms
  + calibrated_share_form.gms
  + calibrated_share_form_CD.gms
  + harberger_check.gms
  + harberger_check_2.gms

+ どのファイルがどのようなプログラムかは解説書を読んでください。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
