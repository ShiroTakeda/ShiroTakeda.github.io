
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:44:14 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ 以下がプログラムのファイルです。
  + benchmark_replication_check.gms
  + benchmark_replication_check_corrected.gms
  + check_exercise.gms
  + check_exercise_corrected.gms
  + cleanup_calc_check.gms
  + other_check.gms
  + other_check_corrected.gms

+ どのファイルがどのようなプログラムかは解説書を読んでください。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
