
First-written:	<2017/03/03>
Time-stamp:	<2017-03-30 11:51:02 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ 以下がプログラムのファイルです。
  + benchmark_replication_check_cns.gms: 
  + benchmark_replication_check_corrected_cns.gms
  + benchmark_replication_check_corrected_mcp.gms
  + benchmark_replication_check_corrected_nlp.gms
  + benchmark_replication_check_mcp.gms
  + benchmark_replication_check_nlp.gms

+ どのファイルがどのようなプログラムかは解説書を読んでください。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
