
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:30:57 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ mcp_sample.gms
  + MCP を解く方法を解説するプログラム

+ mcp_sample_alt_a.gms
+ mcp_sample_alt_b.gms
+ mcp_sample_alt_c.gms
  + MCP を解く方法を解説するプログラム

+ profit_max.gms
  + 利潤最大化問題を解くプログラム

+ util_max.gms
  + 効用最大化問題を解くプログラム

* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
