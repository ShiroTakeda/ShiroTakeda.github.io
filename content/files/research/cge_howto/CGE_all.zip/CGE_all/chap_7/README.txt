
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:39:09 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ Part_7_SAM_example.xlsx
  + 例として使う SAM が入ったファイル

+ Part_7_IO_japan_15x13.xlsx
  + 例として使う日本の産業連関表のファイルです。

+ Part_7_SAM_Japan.xlsx
  + Part_7_IO_japan_15x13.xlsx から作成した SAM が入ったファイルです。

+ Part_7_IO_japan_51x42.xlsx
  + 練習問題用の産業連関表です。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
