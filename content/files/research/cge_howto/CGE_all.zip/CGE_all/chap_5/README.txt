
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:23:13 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt
  + このファイルです。

+ ge_sample_dual.gms
  + 伝統的アプローチで記述したプログラム

+ ge_sample_trad.gms
  + 双対アプローチで記述したプログラム


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
