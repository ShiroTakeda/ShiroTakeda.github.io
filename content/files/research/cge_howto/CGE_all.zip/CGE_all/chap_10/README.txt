
First-written:	<2017/03/03>
Time-stamp:	<2017-04-02 20:45:57 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ 以下がプログラムのファイルです。
  + model_original.gms
  + model_alternative.gms
  + model_normalize.gms
  + Part_10_SAM_example.xlsx

+ どのファイルがどのようなプログラムかは解説書を読んでください。


* 実行方法

+ GAMSIDE でプログラムのファイルを開いて、そのまま実行してください。







--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
