
First-written:	<2017/03/03>
Time-stamp:	<2022-01-19 13:30:52 st>

--------------------------------------------------------------------------

* ファイルの説明

+ README.txt: このファイルです。

+ ide_howto.gms
  + GAMSIDE の利用方法を学ぶためのファイル

+ utility_max.gms
  + 効用最大化問題を GAMS で解くファイル。

+ expenditure_min.gms
  + 支出最小化問題を GAMS で解くファイル。


どのファイルがどのようなプログラムか詳しくは解説書を読んでください。


* 実行方法

+ GAMS Studio などでプログラムのファイルを開いて、そのまま実行してください。






--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
