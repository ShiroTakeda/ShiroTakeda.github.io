
First-written:  <2012/10/09>
Time-stamp:	<2012-10-09 11:05:28 Shiro Takeda>

--------------------------------------------------------------------------

* ファイルの説明

link_settings.gms	リンクのタイプによる設定の変更をおこなうファイル
cr_share.gms		CDMのシナリオにおけるCERの供給シェアの設定
ptrade_dl.gms		直接リンク用のシナリオの設定
ptrade_cdm.gms		CDM用のシナリオの設定
rdr_default.gms		削減率の設定
rdr_halve.gms		削減率の設定（削減率を1/2にするケース）
pol_default.gms		税に関する設定等（とりあえず変更の必要なし）

xxx.sce というような名前のファイル
+ これはシナリオ毎の設定を記述するファイル。
+ xyzというシナリオ名の場合、xyz.sceというファイルを読み込む。




--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
