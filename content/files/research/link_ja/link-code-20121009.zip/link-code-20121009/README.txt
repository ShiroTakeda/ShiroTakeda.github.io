
First-written:	<2012/10/09>
Time-stamp:	<2012-10-09 12:09:59 Shiro Takeda>

--------------------------------------------------------------------------

* プログラムの説明

このプログラムは、

武田史郎・杉野誠・有村俊秀・山崎雅人, (2012), 「排出量取引の国際リンク及びCDMの経
済分析」, 有村俊秀・武田史郎（編）『排出量取引と省エネルギーの経済分析: 日本企業
と家計の現状』, 日本評論社, 第3章．

のシミュレーションをおこなうためのプログラムです。

モデルについての説明は上記の書籍を参考にしてください。

** 謝辞

このプログラムを作成するにあたって、Thomas F. Rutherfor氏が作成した様々なプログラ
ムを利用させていただいた。有益なプログラムを利用させていただいたことに感謝します。
GTAP7inGAMS は Rutherford氏のウェブサイト <http://www.mpsge.org/> から入手可能で
す。

** プログラムを実行するのに必要なもの

+ GAMS base module + Solver PATH + Solver MPSGE
+ GTAP7.1データ

GAMS本体（GAMS base module）に加えて、PATHとMPSGEの二つのソルバーが必要です。また、
ベンチマークデータにGTAP7.1が必要になります。

*** データについて

シミュレーションを行うには、ベンチマークデータとして利用しているGTAP7.1データが必
要になりますが、GTAPデータは商用のデータで配布禁止ですから、プログラムには含めて
いません。ただし、GTAPデータのライセンスを保有している人には、このプログラム用の
データを配布することが可能ですので、もし必要な方は武田（shiro.takeda@gmail.com）
まで連絡をください。

ベンチマークデータは基本的にはGTAP7.1データで、同封のマッピングファイル
（link-22x12.map）を利用すれば似たようなデータを自分で作成することもできます。し
かし、データにはThomas F. Rutherford氏が作成したGTAP7inGAMSを利用し様々な加工をほ
どこしていますので、全く同じデータを自分で作成することは難しいです。元のGTAP7.1デー
タをどのように加工しているかを知りたい方は、武田（shiro.takeda@gmail.com）まで連
絡をください。

** プログラムの実行方法

プログラムの実行方法

+ gam.exeのあるフォルダにPATHを通す。
+ run_scenarios.bat を実行する。

これで基準ケースを解きます（感応度分析のケースを解くには、run_scenarios.batを少し
修正する必要があります）。さらに、

+ export_excel.bat を実行する

と、計算結果が "\results\link_summary_results.xlsx" に出力されます。

［注］
+ GAMSIDEで"link_main_dynamic_20121009.gms"を実行するのでもモデルを解けますが、
  その場合には、直接リンクのケースしか計算しません。
+ GAMSIDE上で直接リンク以外のケースを計算する場合には、
  link_main_dynamic_20121009.gmsを自分で書き換える必要があります。


* シナリオの説明

s_dl			直接リンク
s_cdm			CDM (制限なし)
s_cdm_lim		CDM (制限なし)

以下は感応分析のシナリオ

Armington弾力性を2倍にしたケース
+ s_dl_ae_l		
+ s_cdm_ae_l
+ s_cdm_lim_ae_l

Armington弾力性を1/2倍にしたケース
+ s_dl_ae_s
+ s_cdm_ae_s
+ s_cdm_lim_ae_s

代替の弾力性を2倍にしたケース
+ s_dl_eos_l
+ s_cdm_eos_l
+ s_cdm_lim_eos_l

代替の弾力性を1/2倍にしたケース
+ s_dl_eos_s
+ s_cdm_eos_s
+ s_cdm_lim_eos_s

削減率を1/2倍にしたケース
+ s_dl_lrd
+ s_cdm_lrd
+ s_cdm_lim_lrd



--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
