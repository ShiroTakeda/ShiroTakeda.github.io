Filename:            README.txt
Author:              Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/03/01>
Time-stamp:          <2006-11-13 15:37:04 Shiro Takeda>
Version:
$Id: README.txt,v 1.1 2006/11/13 06:38:32 st Exp $

--------------------------------------------------------------------------
[Requirement]

To run the simulation, you need the following programs and GAMS solver.

   + gams-f utility
   + gmsunzip.exe and har2gdx.exe
   + Solver PATH

   In addition, if you export outputs to excel files, then you need

   + xldump utility

Check if these programs are installed on your PC.  Needless to say, you
need to have GTAP 6 dataset.

The file "gtap6data.gms" is originally provided in GTAPinGAMS created by
Thomas F. Rutherford although I slightly modified its contents.  I would
like to thank him for providing the useful program.  Moreover, in writing
programs included in this archive, I have greatly benefited from programs
of the Uruguay round model created by Glenn W. Harrison,
Thomas. F. Rutherford, David G. Tarr and other GAMS programs written by
Tom Rutherford.  I would like to express acknowledgment to them.


[How to run the simulation]
                                
[1] First, you need to create the aggregated dataset from the original
GTAP 6 data.  The aggregation needs to be done by application GTAPAgg6
with "trade_lib.agg" under the current directory as an gggregation scheme
file.  If you accomplish the aggregation, you get trade_lib.zip.  Then
extract it into the current directory. 

[2] To run the simulation, execute "run_base_scenarios.bat".  This will
generate the results displayed in Table 4 in the paper.  EV is reported 
by "l_ev" parameter in the lst file.  In addition, the results will be
stored in excel file placed at "results" directory.  To solve the model,
gams.exe must be included in environmental variable PATH.
Similarly, if you solve sensitivity analysis, execute
"run_sensitivity_analysis.bat". 

Note that computation will require much time (maybe over an hour) although
it depends on ability of your PC.  And note that the size of lst files
created by the simulation is very large (about 100MB per each lst file).

For the details of the model implemented in this program, see the papers
distributed with this archive.  If you have any question about the
program, email me <zbc08106@park.zero.ad.jp>.

--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
