Filename:            README.txt
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/10/18>
Time-stamp:	     <2006-11-13 15:33:07 Shiro Takeda>
$Id: README.txt,v 1.2 2006/11/13 06:38:24 st Exp $

-------------------------------------------------------------

Read README.txt file under "trade_lib" directory.


--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
