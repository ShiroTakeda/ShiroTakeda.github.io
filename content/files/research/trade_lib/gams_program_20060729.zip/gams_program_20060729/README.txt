Filename:            README.txt
Author:              Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/03/01>
Time-stamp:          <2006-07-29 22:59:43 Shiro Takeda>
Version:
$Id: README.txt,v 1.1 2006/07/29 14:01:43 st Exp $

--------------------------------------------------------------------------
[Requirement]

To run the simulation, you need the following programs and GAMS solver.

   + gams-f utility
   + gmsunzip.exe and har2gdx.exe
   + Solver PATH

   In addition, if you export outputs to excel files, then you need

   + xldump utility

Check if these programs are installed on your PC.  Needless to say, you
need to have GTAP 6 dataset.

[Description of files]

run_scenarios.bat               Batch file for executing the simulation.
run_one_scenario.bat            Batch file called from run_scenarios.bat.
gtap6data.gms                   Program for importing data.
trade_lib.gms                   Main routine gms file.
trade_lib_calibration.gms       Program for calibration.
trade_lib_data.gms              Program for importing data.
trade_lib_initial_values.gms    Program for defining initial values of variables.
trade_lib_model.gms             Model description.
trade_lib_parameter.gms         Program for defining parameters.
trade_lib_model_choice.gms      
trade_lib_par_for_results.gms   Program for defining parameters.
tariff_on_services.gms          Data of tariffs on services trade.
default_data.agg		Aggregation scheme file for GTAPAgg6.

default_data/				Directory in which you put the data file.
default_data/trade_lib_set_def.gms      Declaration of service sectors.
default_data/tariff_on_services.gms	Data of services tariffs.
default_data/cdr.gms			Data of CDR.
default_data/scn_***.gms		Liberalization scenario files.
default_data/results/           	Directory in which output files will be stored.


The file "gtap6data.gms" is originally provided in GTAPinGAMS created by
Thomas F. Rutherford although I slightly modified its contents.  I would
like to thank him for providing the useful program.  Moreover, in writing
programs included in this archive, I have greatly benefited from programs
of the Uruguay round model created by Glenn W. Harrison,
Thomas. F. Rutherford, David G. Tarr and other GAMS programs written by
Tom Rutherford.  I would like to express acknowledgment to them.


[How to run the simulation]
                                
[1] First, you need to create the aggregated dataset from the original
GTAP 6 data.  The aggregation needs to be done by application GTAPAgg6
with "default_data.agg" as an gggregation scheme file.  If you accomplish
the aggregation, you get default_data.zip.  Then extract it into the
default_data directory.

[2] To run the simulation, execute "run_scenarios.bat".  This will
generate the results displayed in Table 4 in the paper.  The percentage
change in utility is reported by the parameter "pc_u" in the lst file.  In
addition, the results will be stored in excel files placed at
default_data/results directory.

Note that computation will require much time (maybe over an hour) although
it depends on ability of your PC.  And note that the size of lst files
created by the simulation is very large (over 100MB).

For the details of the model implemented in this program, see the papers
distributed with this archive.  If you have any question about the
program, email me <zbc08106@park.zero.ad.jp>.


--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
