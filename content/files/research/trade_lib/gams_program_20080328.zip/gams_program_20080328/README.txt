Filename:            README.txt
Author:              Shiro Takeda
e-mail               <shiro.takeda@gmail.com>
First-written:       <2006/03/01>
Time-stamp:          <2008-03-28 17:11:16 Shiro Takeda>
Version:

--------------------------------------------------------------------------

This archive includes the programs for the simulation in

Shiro Takeda (2008),
"A CGE Analysis of the Welfare Effects of Trade Liberalization under
Different Market Structures"

See README.txt file in the default_data directory.


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
