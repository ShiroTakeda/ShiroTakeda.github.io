Filename:            README.txt
Author:              Shiro Takeda
e-mail               <shiro.takeda@gmail.com>
First-written:       <2006/03/01>
Time-stamp:          <2008-03-28 15:32:04 Shiro Takeda>
Version:

--------------------------------------------------------------------------
[Requirement]

To run the simulation, you need the following programs and GAMS solver.

   + gams-f utility
   + xldump utility
   + gmsunzip.exe and har2gdx.exe
   + Solver PATH

Check if these programs are installed on your PC.  In addition, you need
to have GTAP 6 dataset.

The file gtap6data.gms is originally provided in GTAPinGAMS created by
Thomas F. Rutherford although I slightly modified its contents.  I would
like to thank him for providing the useful program.


[How to run the simulation]
                                
[1] First, you need to create the aggregated dataset from the original
GTAP 6 data.  The aggregation needs to be done by application GTAPAgg6
with "gtap6_trade_lib.agg" as an gggregation scheme file.  If you
accomplish the aggregation, save gtap6_trade_lib.zip that includes the
aggregated dataset into the current directory.

[2] To run the simulation, execute "run_scenarios.bat".  This will
generate the results displayed in Table 4 in the paper.  The results will
be stored in excel files placed at ./results directory.  Note that
computation will require much time (maybe over an hour) although it
depends on ability of your PC.

If you want to run other simulations, you need to rewrite programs.  If
you have any question about the program, email me
<shiro.takeda@gmail.com>


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
