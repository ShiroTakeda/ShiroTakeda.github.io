Filename:            README.txt
Author:              Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/03/01>
Time-stamp:          <2006-07-22 13:23:28 Shiro Takeda>
Version:
$Id: README.txt,v 1.6 2006/07/22 04:23:51 st Exp $

--------------------------------------------------------------------------
[Requirement]

To run the simulation, you need the following programs and GAMS solver.

   + gams-f utility
   + xldump utility
   + gmsunzip.exe and har2gdx.exe
   + Solver PATH

Check if these programs are installed on your PC.  In addition, you need
to have GTAP 6 dataset.

[Description of files]

run_scenarios.bat               Batch file for executing the simulation.
run_one_scenario.bat            Batch file called from run_scenarios.bat.
gtap6data.gms                   Program for importing data.
trade_lib.gms                   Main routine gms file.
trade_lib_calibration.gms       Program for calibration.
trade_lib_data.gms              Program for importing data.
trade_lib_initial_values.gms    Program for defining initial values of variables.
trade_lib_model.gms             Model description.
trade_lib_parameter.gms         Program for defining parameters.
trade_lib_set_def.gms           Declaration of service sectors.
trade_lib_model_choice.gms      
trade_lib_par_for_results.gms   Program for defining parameters.
tariff_on_services.gms          Data of tariffs on services trade.

scenario/scn_*.gms              Liberalization scenario files.
agg_scheme/gtap6_trade_lib.agg  Aggregation scheme file for GTAPAgg6.
result/                         Directory in which output files will be stored.


The file "gtap6data.gms" is originally provided in GTAPinGAMS created by
Thomas F. Rutherford although I slightly modified its contents.  I would
like to thank him for providing the useful program.


[How to run the simulation]
                                
[1] First, you need to create the aggregated dataset from the original
GTAP 6 data.  The aggregation needs to be done by application GTAPAgg6
with "gtap6_trade_lib.agg" as an gggregation scheme file.  If you
accomplish the aggregation, save gtap6_trade_lib.zip that includes the
aggregated dataset into the current directory.

[2] To run the simulation, execute "run_scenarios.bat".  This will
generate the results displayed in Table 7 in the paper.  The results will
be stored in excel files placed at ./result directory.  Note that
computation will require much time (maybe over an hour) although it
depends on ability of your PC.

If you want to run other simulations, you need to rewrite programs.  If
you have any question about the program, email me
<zbc08106@park.zero.ad.jp>.


--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
