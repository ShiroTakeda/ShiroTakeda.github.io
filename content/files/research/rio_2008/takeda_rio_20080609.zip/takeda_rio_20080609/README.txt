Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/12/20>
Time-stamp:	       <2008-06-09 16:01:21 Shiro Takeda>

--------------------------------------------------------------------------

このzipファイルには

武田史郎、伴金美 (2008) 『貿易自由化の効果における地域間格差：地域間産業連
関表を利用した応用一般均衡分析』

のシミュレーションをおこなうためのプログラムが含まれています。

o gams_programフォルダ以下にはGAMSのプログラムがあります。
o GTAPフォルダには交易条件変化を求めるためのGTAPプログラムがあります。

詳しいことは各フォルダ内のREADME.txtファイルを読んでください。


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
