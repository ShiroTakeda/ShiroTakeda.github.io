Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/20/19>
Time-stamp:	       <2008-06-09 15:55:03 Shiro Takeda>

このフォルダにあるファイルは、交易条件の変化を求めるためのGTAPモデル用のプ
ログラムです。

----------------------------------
ファイルの説明．
----------------------------------

・"gtap_23x2.agg"

このファイルを aggregation scheme ファイルとして，GTAP6 データを統合してい
ます．

・"lib.EXP"

GEMPACK (RunGTAP) でシミュレーションをおこなうための設定ファイルです。

・"tot_change.xls"

結果を載せたファイルです。


----------------------------------
シミュレーションの説明．
----------------------------------

・まず、gtap_23x2.aggをaggregation scheme fileとしてGTAP6データを統合する
(JPNとROWの2地域、23部門)。

・統合したデータを利用し、lib.EXPの設定でRunGTAPで自由化のシミュレーション
をおこなう。自由化＝関税、輸出税の完全な撤廃。モデルは標準的なgtap.tab
(ver.6.2)、パラメータはdefault.prmを利用。その他の設定はlib.expを参照。

・結果から、pfobとpcifの数値を取り出す (tot_change.xlsに載せてある値)。

・"pfob-pcif"の値を各財の交易条件の変化率とみなす。

・それをGAMSのほうのモデルに適用。


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
