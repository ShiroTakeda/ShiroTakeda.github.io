Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/12/20>
Time-stamp:	       <2008-10-02 14:40:38 Shiro Takeda>

--------------------------------------------------------------------------

新井園枝・尾形正之(2006) 「平成12 年試算地域間産業連関表の概要」、『経済統計研究』、
第34 巻、第3 号、1-22 頁．

の試算地域間産業連関表を変換するプログラム．

* まず、excel のデータをGAMSで扱いやすい gdx に変換
* 52部門・9地域 → 23部門・8地域に統合

の二つの作業をおこなう．

[準備]

bat fileを実行するにはgamsにpathが通っている必要があります。


[手順]

(1) run_xls2gdx.bat を実行する．

これは excel データを gdx データに変換するプログラム．

RegionIO52.xls → RegionIO52.gdx が作成される．

(2) run_data_aggregation.bat を実行

これは aggregation のプログラム．

デフォールトでは 23 部門，8 地域に統合する．その mapping が指定されている
ファイルが "dataio_23x8.map"．

RegionIO52.gdx が統合されて dataio_23x8.gdx が作成される．

作成された dataio_23x8.gdx を simulation フォルダに移動．


--------------------
Local Variables:
fill-column: 80
End:
