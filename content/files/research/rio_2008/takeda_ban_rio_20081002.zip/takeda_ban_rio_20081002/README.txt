Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/12/20>
Time-stamp:	       <2008-10-02 14:38:30 Shiro Takeda>

--------------------------------------------------------------------------

このzipファイルには

武田史郎、伴金美 (2008) 『貿易自由化の効果における地域間格差：地域間産業連
関表を利用した応用一般均衡分析』、RIETI Discussion Paper Series 08-J -053．

のシミュレーションをおこなうためのプログラムが含まれています。

o gams_programフォルダ以下にはGAMSのプログラムがあります。
o GTAPフォルダには交易条件変化を求めるためのGTAPプログラムがあります。

詳しいことは各フォルダ内のREADME.txtファイルを読んでください。

--------------------
Local Variables:
fill-column: 80
End:
