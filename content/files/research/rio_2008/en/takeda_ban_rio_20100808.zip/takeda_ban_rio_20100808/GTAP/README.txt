Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/20/19>
Time-stamp:	       <2008-11-17 16:47:11 Shiro Takeda>

Files in this folder are GTAP programs for the derivation of change in
terms of trade.

----------------------------------
Explanation of files.
----------------------------------

* "gtap_23x2.agg"

Aggregation scheme file for GTAP 6 data.

* "lib.EXP"

Configuration file for GEMPACK (RunGTAP).

* "tot_change.xls"

This file includes results.


----------------------------------
Explanation of the simulation.
----------------------------------

* First, aggregate GTAP 6 data by the aggregation scheme file "gtap_23x2.agg".  The aggregated data
includes two regions (Japan and the rest of the world) and 23 sectors.

* Second, execute the simulation with lib.EXP in RunGTAP.  

* The simulation generates values of pfob and pcif, which are reported in
  "tot_change.xls".

* Then, we regard the value of "pfob-pcif" as percentage change in terms
  of trade (TOT) for each commodity.

* Finally, apply the change in TOT derived here to the GAMS simulation.


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
