Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/12/20>
Time-stamp:	       <2008-11-17 16:40:28 Shiro Takeda>

--------------------------------------------------------------------------

This zip file includes programs used in the simulation in the following paper:

Takeda, Shiro and Kanemi Ban (2008) "Regional Effects of Trade
Liberalization in Japan: A CGE Analysis Based on Inter-Regional IO Table,"
November. Available at http://shirotakeda.org/.

o gams_program folder includes main GAMS programs.
o GTAP folder includes GTAP program used for the derivation of change in terms of trade.

For the details, read README.txt files in each folder.


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
