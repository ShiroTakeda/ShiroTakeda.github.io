Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2007/12/20>
Time-stamp:	       <2008-11-17 17:21:37 Shiro Takeda>

--------------------------------------------------------------------------

This folder contains program to aggregate "Inter-Regional Input-Output
Table for Japan 2000" provided by

Arai, Sonoe and Masayuki Ogata (2006) "Summary of Inter-Regional
Input-Output Table for Japan 2000", Economic and Statistical Research,
Vol.34, No.3, pp.1-22 (in Japanese, Heisei 12 nen sisan chiikikan sangyou
renkanhyou no gaiyou, keizai toukei kenkyu).

There are two programs:

* First, convert excel to gdx.
* Second, aggregated 52 sectors adn nine regions to 23 sectors and eight regions

[Preliminary]

To run bat files, you need to add the GAMS directory to your path.


[Procedure]

(1) Execute run_xls2gdx.bat.

This converts excel data (RegionIO52.xls) to gdx data (RegionIO52.gdx).

(2) Second, run run_data_aggregation.bat.

This aggregates the data in "RegionIO52.gdx" and creates "dataio_23x8.gdx".

By default, it aggregates the original 52 sectors and 9 regions to 23 sectors and 8 regions.
Mapping for aggregation is defined in  "dataio_23x8.map".

(3) Move "dataio_23x8.gdx" to folder "simulation".

--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
