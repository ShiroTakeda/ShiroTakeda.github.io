Filename:            README.txt
Author:		     Shiro Takeda
First-written:       <2006/10/18>
Time-stamp:	     <2008-11-17 17:57:15 Shiro Takeda>

$Id: README_ja.txt,v 1.1 2007/03/19 04:09:31 st Exp $

This file explains how to run GAMS simulation.

======================================================
Notes
======================================================

[Note 1] "GAMS folder" in the explaination below indicates GAMS system folder.
For example, if you installed GAMS in "c:\GAMS22.2", then "GAMS folder" is
"c:\GAMS22.2".

[Note 2] "Current folder" is the folder where this README.txt file exists.


======================================================
Preliminary
======================================================

To run the simulation, you need the following programs and GAMS solver.

* GAMS base system
* MCP solver
* MPSGE (not necessarily required)

In GAMS programs, the same model is written both in normal MCP format and MPSGE format.

"model_mcp.gms" -> model written in normal MCP format.
"model_mpsge.gms" -> model written in MPSGE format.

In the default case, we use "model_mcp.gms".


======================================================
How to run simulations.
======================================================

To run the simulation, execute "run_model.bat".  This will generate the results
of the benchmark case and five sensitivity experiments.  The results will be
stored in excel files placed at ./results directory.


======================================================
How to use different data.
======================================================

The default simulation use 23 sectors and 8 regions data.  If you want to use
other aggregation, see README.txt file in "data_aggregation" folder.

--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
