$title A CGE model for analysis of CBAM
$ontext
Time-stamp:     <2026-03-15 22:28:43 st>

+ This program is for analysis of carbon border adjustment mecahism (CBAM)

+ Unit is Billions of US$.

$offtext

*       Solution printing:
* option solprint=on;

option dispWidth = 12;

*       ----------------------------------------------------------------------
display "@ Definitions of control variables";

*       ----------------------------------------------------------------------

*       Scenario name
$if not setglobal scen_name $setglobal scen_name s_default

*       Data name
$if not setglobal ds_name $setglobal ds_name cbam_18x17_gtap10ingams

*       Decimal
$if not setglobal ds_decimal $setglobal ds_decimal gsd_3

*       File name of data
$if not setglobal ds $setglobal ds .\data\%ds_name%_%ds_decimal%

*       Name of file for index definition
$if not setglobal set_file $setglobal set_file .\data\%ds_name%.set

*       List of scenarios solved.
$if not setglobal s_ncba	$setglobal s_ncba 1
$if not setglobal wcbam         $setglobal wcbam 1
$if not setglobal cbam2         $setglobal cbam2 1
$if not setglobal cbam3         $setglobal cbam3 1
$if not setglobal cbam4         $setglobal cbam4 1
$if not setglobal cbam5         $setglobal cbam5 1
$if not setglobal cbam6		$setglobal cbam6 1

*       Labor tax rate for Japan (net base，%):
$if not setglobal ltax_jpn $setglobal ltax_jpn 50

*       Non-zero -> Utility depends on not only consumption but also saving.
$if not setglobal fl_vinv $setglobal fl_vinv 0

*       Non-zero -> Emissions from industrial process are included.
$if not setglobal fl_proc $setglobal fl_proc 1

*       Specification of the name of the configuration file for the policy instrument.
$if not setglobal pol_inst_file $setglobal pol_inst_file .\scenarios\pol_inst_default.gms

*       Specification of the name of the configuration file for the policy scenario.
$if not setglobal pol_sce_file $setglobal pol_sce_file .\scenarios\pol_scenario_default.gms

*       Specification of the file name of the elasticity of substitution configuration.
$if not setglobal eos_file $setglobal eos_file .\data\eos_%ds_name%.gms

*       Non-zero -> Only Benchmark replication is performed.
$if not setglobal br_only $setglobal br_only 0

*       Non-zero -> Only cleanup calculation is performed.
$if not setglobal cc_only $setglobal cc_only 0

*       Non-zero -> Only scale shock experimtn is performed.
$if not setglobal scale_shock $setglobal scale_shock 0

*       Scale parameter for EOS parameters
$if not setglobal s_eos $setglobal s_eos 1

*       Scale parameter for Armington elasticity
$if not setglobal s_arm $setglobal s_arm 1

*       Non-zero -> Debug mode
$if not setglobal fl_debug $setglobal fl_debug 1

set     allr    /
EUR
GBR
OEU
JPN
USA
RUS
CAN
ANZ
KOR
CHN
IND
BRA
TUR
ASE
OEX
MIC
LIC
/
alli    /
I_S
NFM
CHM
OCH
NMM
PPP
P_C
ELY
OIL
COA
GAS
AGR
MAC
OMF
CNS
ATP
TRN
SER
/;

display allr, alli;

parameter
    fl_debug            / %fl_debug% /
    fl_proc             / %fl_proc% /
;
display fl_debug, fl_proc;

if(fl_debug,
    option solprint = on;
else
    option solprint=off;
);

*       ----------------------------------------------------------------------
display "@ Data";

*       ----------------------------------------------------------------------

*       ------------------------------------------------------------

display "@@ Import data";
*       ------------------------------------------------------------

* $offlisting
$include gtap10data.gms
* $onlisting

alias (i,ii), (i,j), (r,rr), (s,ss), (f,ff);

display g, r, i, f, mf, sf;
display vfm, vdfm ,vifm, vxmd, vst, vtwr;
display vdm, vom;
display pvxmd, pvtwr;
display vtw, vom, vdm, vim, evom, vb;
display esubd, esubva, esubm, etrae, eta, epsilon;
display rto, rtf, rtfd, rtfi, rtxs, rtms;

*       ----------------------------------------------------------------------
display "@@@ Index file";

* gams-include-file: .\data\cbam_18x17_gtap10ingams.set
$include .\data\%ds_name%.set

neint(i)$((not eite(i)) and (not e(i)) and (not svces(i)) and (not trans(i))) = yes;
nr(i,r) = yes$(vom(i,r)$(not xe(i)));

display ely, p_c, gas, en, xe, fe, e, lqd, nr, k, eite, eint, svces, trans, man, neint, ssec, cba;

*       ----------------------------------------------------------------------
*       Index for regions.
set
    r_r(r,s)    "Yes if r = r"
    r_s(r,s)    "Yes if r = s"
;
r_r(r,s)$sameas(r,s) = yes;
r_s(r,s)$(not sameas(r,s)) = yes;
display r_r, r_s;

*       ----------------------------------------------------------------------
display "@@ Remove small values from data";

parameter chk_vifm, chk_vdfm, chk_decimal;

chk_decimal = 6;

chk_vifm(i,j,r)$(vifm(i,j,r) < 1/chk_decimal) = 1;
chk_vdfm(i,j,r)$(vdfm(i,j,r) < 1/chk_decimal) = 1;
chk_vifm(i,"c",r)$(vifm(i,"c",r) < 1/chk_decimal) = 1;
chk_vdfm(i,"c",r)$(vdfm(i,"c",r) < 1/chk_decimal) = 1;
chk_vifm(i,"g",r)$(vifm(i,"g",r) < 1/chk_decimal) = 1;
chk_vdfm(i,"g",r)$(vdfm(i,"g",r) < 1/chk_decimal) = 1;
chk_vifm(i,"i",r)$(vifm(i,"i",r) < 1/chk_decimal) = 1;
chk_vdfm(i,"i",r)$(vdfm(i,"i",r) < 1/chk_decimal) = 1;

display chk_vifm, chk_vdfm;

vifm(i,j,r) = round(vifm(i,j,r), chk_decimal);
vdfm(i,j,r) = round(vdfm(i,j,r), chk_decimal);
vifm(i,"c",r) = round(vifm(i,"c",r), chk_decimal);
vdfm(i,"c",r) = round(vdfm(i,"c",r), chk_decimal);
vifm(i,"g",r) = round(vifm(i,"g",r), chk_decimal);
vdfm(i,"g",r) = round(vdfm(i,"g",r), chk_decimal);
vifm(i,"i",r) = round(vifm(i,"i",r), chk_decimal);
vdfm(i,"i",r) = round(vdfm(i,"i",r), chk_decimal);

vxmd(i,r,s) = round(vxmd(i,r,s), chk_decimal);

parameter
    pvx(i,s,r)          Export price (world price)
    pvxmd(i,s,r)        Import price (power of benchmark tariff)
    pvxmd_(i,s,r)       Import price (power of benchmark tariff)
    pvtwr(i,s,r)        Import price for transport services
    vxmd_(i,s,r)        Export at world price
    vtwr_ce(j,i,s,r)
;
pvx(i,s,r) = (1 - rtxs0(i,s,r));
pvxmd(i,s,r) = (1+rtms0(i,s,r)) * (1-rtxs0(i,s,r));
pvxmd_(i,s,r) = 1 + rtms0(i,s,r);
pvtwr(i,s,r) = 1 + rtms0(i,s,r);

vxmd_(i,s,r) = pvx(i,s,r) * vxmd(i,s,r);

display pvx, pvxmd, pvxmd_, pvtwr, vxmd_;

vtwr_ce(j,i,s,r)$vxmd_(i,s,r) = vtwr(j,i,s,r) / vxmd_(i,s,r);

*       ----------------------------------------------------------------------
display "@@ Definition of additional parameters";

parameter
    vipm        "Private consumption demand for import goods"
    vdpm        "Private consumption demand for domestic goods"
    rtpd        "Tax rates on private consumption of imported goods"
    rtpi        "Tax rates on private consumption of imported goods"
    vpm         "Total private consumption"

    vigm        "Government consumption demand for import goods"
    vdgm        "Government consumption demand for domestic goods"
    rtgd        "Tax rates on government consumption of imported goods"
    rtgi        "Tax rates on government consumption of imported goods"
    vgm         "Total government consumption"

    viim        "Investment demand for import goods"
    vdim        "Investment demand for domestic goods"
    rtid        "Tax rates on investment of imported goods"
    rtii        "Tax rates on investment of imported goods"
    vinv        "Total investment"
;
vdpm(i,r) = vdfm(i,"c",r);
vipm(i,r) = vifm(i,"c",r);
rtpd(i,r) = rtfd0(i,"c",r);
rtpi(i,r) = rtfi0(i,"c",r);
vpm(r) = sum(i, (1+rtpd(i,r))*vdpm(i,r) + (1+rtpi(i,r))*vipm(i,r));

vdgm(i,r) = vdfm(i,"g",r);
vigm(i,r) = vifm(i,"g",r);
rtgd(i,r) = rtfd0(i,"g",r);
rtgi(i,r) = rtfi0(i,"g",r);
vgm(r) = sum(i, (1+rtgd(i,r))*vdgm(i,r) + (1+rtgi(i,r))*vigm(i,r));

vdim(i,r) = vdfm(i,"i",r);
viim(i,r) = vifm(i,"i",r);
rtid(i,r) = rtfd0(i,"i",r);
rtii(i,r) = rtfi0(i,"i",r);
vinv(r) = sum(i, (1+rtid(i,r))*vdim(i,r) + (1+rtii(i,r))*viim(i,r));

* display vdpm, vipm, vdgm, vigm, vdim, viim;
* display vpm, vgm, vinv;

*	Initial values of tax rates.
parameter
    rtpd0
    rtpi0
    rtgd0
    rtgi0
    rtid0
    rtii0
;
rtpd0(i,r) = rtpd(i,r);
rtpi0(i,r) = rtpi(i,r);
rtgd0(i,r) = rtgd(i,r);
rtgi0(i,r) = rtgi(i,r);
rtid0(i,r) = rtid(i,r);
rtii0(i,r) = rtii(i,r);

parameter
    pcd0(i,r)           "Reference price for private consumption (domestic)"
    pci0(i,r)           "Reference price for private consumption (import)"
    pintd0(i,j,r)       "Reference price for intermediate input (domestic)"
    pinti0(i,j,r)       "Reference price for intermediate input (import)"
;
pcd0(i,r) = 1 + rtpd0(i,r);
pci0(i,r) = 1 + rtpi0(i,r);
display pcd0, pci0;

pintd0(i,j,r) = 1 + rtfd0(i,j,r);
pinti0(i,j,r) = 1 + rtfi0(i,j,r);
display pintd0, pinti0;

parameters
    vafm(i,j,r)         "Aggregate intermediate inputs"
    vapm(i,r)           "Private consumption expenditure"
    vafma(i,r)
;
vafm(i,j,r) = pintd0(i,j,r)*vdfm(i,j,r) + pinti0(i,j,r)*vifm(i,j,r);
vapm(i,r)   = pcd0(i,r)*vdpm(i,r) + pci0(i,r)*vipm(i,r);
display vafm, vapm;

vafma(i,r) = sum(fe, vafm(fe,i,r));
display vafma;

parameter
    chk_vafm_p_c
    chk_vafm_oil_use;

chk_vafm_p_c(i,r) = vafm(i,"p_c",r);
chk_vafm_oil_use(i,r) = round(vafm("oil",i,r), 4);

*       ----------------------------------------------------------------------
display "@@ CO2 emissions data";

parameter
    co2f(i,j,r)         "CO2 emissions from input i in sector j (MtCO2)"
    co2h(i,r)           "CO2 emissions from input i in households (MtCO2)"
    co2g(i,r)           "CO2 emissions from input i in government (MtCO2)"
    co2bench(*)         "Benchmark CO2 emission in region r (MtCO2)"
    co2lim(r)           "CO2 emission limit (MtCO2)"
    co2p(j,r)           "CO2 emission from industrial process (MtCO2)"
;
co2f(en,j,r) = eco2d(en,j,r) + eco2i(en,j,r);
co2h(en,r)   = eco2d(en,"c",r) + eco2i(en,"c",r);

co2p(j,r) = 0;
co2p("nmm",r) = eco2p(r);

$ontext
GTAP data of CO2 emissions from iron-steel sector (I_S) in Japan

                  JPN
COA.I_S         8.479
P_C.I_S        19.895
GAS.I_S         6.957

CO2 emissions data of 3EID

	JPN
COA     30.5
P_C     108.2
GAS     4.5

Since the emissions of the GTAP data are clearly smaller than those of the 3EID, the data are
corrected.  P_C (- 108.2 18.895) 89.305

COA
(- 30.5 8.479) 22.021

$offtext

co2f("P_C","I_S","JPN") = co2f("P_C","I_S","JPN") + 89.304;
co2f("COA","I_S","JPN") = co2f("COA","I_S","JPN") + 22.021;
display co2f, co2h, co2p;

co2bench(r) = sum((en,j), co2f(en,j,r)) + sum(en, co2h(en,r)) + sum(j, co2p(j,r));
co2bench("sum") = sum(r, co2bench(r));
display "Before adjustment", co2f, co2h, co2bench;

$ontext
If vafm and vapm are zero, then co2 should also be zero. This adjustment results in a (small)
overall decrease in emissions.
$offtext
co2f(en,j,r)$(not vafm(en,j,r)) = 0;
co2h(en,r)$(not vapm(en,r)) = 0;

co2f(en,j,r)$(not vafm(en,j,r)) = 0;
co2h(en,r)$(not vapm(en,r)) = 0;

co2p(j,r)$(not vom(j,r)) = 0;

co2bench(r) = sum((en,j), co2f(en,j,r)) + sum(en, co2h(en,r)) + sum(j, co2p(j,r));
co2bench("sum") = sum(r, co2bench(r));
display "After adjustment", co2bench;

*       Set a tentative value for co2lim parameter.
co2lim(r) = co2bench(r) * 10;

*       ------------------------------------------------------------
display "@@@ Check CO2 data";

parameter
    chk_co2_use         CO2 emissions by use
    chk_co2_use_p_c     CO2 emissions by use in P_C
    chk_co2_so          CO2 emissions by source
    chk_co2_so_sh       CO2 emissions share by source
;
chk_co2_use(j,r) = sum(en, co2f(en,j,r)) + co2p(j,r);
chk_co2_use("HH",r) = sum(en, co2h(en,r));
chk_co2_use("sum",r) = sum(j, chk_co2_use(j,r)) + chk_co2_use("HH",r);
display chk_co2_use;

chk_co2_use_p_c(en,r) = co2f(en,"p_c",r);
display chk_co2_use_p_c;

chk_co2_so(en,r) = sum(j, co2f(en,j,r)) + co2h(en,r);
chk_co2_so("proc",r) = sum(j, co2p(j,r));
chk_co2_so("sum",r) = sum(en, chk_co2_so(en,r)) + chk_co2_so("proc",r);
chk_co2_so_sh(en,r) = 100 * chk_co2_so(en,r) / chk_co2_so("sum",r);
chk_co2_so_sh("proc",r) = 100 * chk_co2_so("proc",r) / chk_co2_so("sum",r);
display chk_co2_so, chk_co2_so_sh;

*       ----------------------------------------------------------------------
display "@@ Fossil fuel sectors and natural resource";

*       ------------------------------------------------------------
$ontext
Natural Resources.
+ In the GTAP data, natural resources are inherently used in multiple sectors.

Fossil fuel sector.
+ Calibrate elasticity of substitution between "resource vs. non-resource inputs"

Method.
+ Elasticity of supply of benchmark fossil fuels -> Elasticity of substitution

$offtext
parameters
    vrd(i,r)		Natural resource demand in the fossil fuel sector
    vrs(i,r)		Supply of natural resources in the fossil fuel sector
    vrs0(i,r)		Supply of natural resources in the fossil fuel sector
    sig_res(i,r)	EOS between natural vs. non-natural resources
    sh_vrd(i,r) 	Share of resource input in cost
    etaf(xe) 		Price elasticity of fossil fuel supply
    rtax0(i,r) 		Tax on resources
    rtax(i,r)
    pres0(i,r) 		Reference price of resource
;

$ontext
The price elasticity of supply of fossil fuels is set at 1.0 based on the following paper

Böhringer, C., Schneider, J. and Asane-Otoo, E., (2021). "Trade in Carbon and Carbon Tariffs."
Environmental and Resource Economics. Available at:
http://link.springer.com/10.1007/s10640-021-00548-y [Accessed March 18, 2021].

$offtext
etaf("oil")  = 1;
etaf("gas")  = 1;
etaf("coa")  = 1;
display etaf;

*       Natural resource demand in the fossil fuel sector
vrd(xe,r) = vfm("res",xe,r);
vfm("res",xe,r) = 0;
vrs0(xe,r) = vrd(xe,r);
vrs(xe,r) = vrs0(xe,r);
display vrd, vrs, vrs0;

rtax0(xe,r) = rtf("res",xe,r);
rtf("res",xe,r) = 0;
rtax(xe,r) = rtax0(xe,r);

pres0(xe,r) = 1 + rtax0(xe,r);
display rtax0, pres0;

*       Calibration
sh_vrd(xe,r)$vom(xe,r) = vrd(xe,r) / (vom(xe,r)*(1 - rto(xe,r)));
sig_res(xe,r)$(1 - sh_vrd(xe,r)) = sh_vrd(xe,r) * etaf(xe) / (1 - sh_vrd(xe,r));
display sh_vrd, sig_res;

*       ----------------------------------------------------------------------
display "@@ Agricultural sector and land";
$ontext
+ Assume that the factor of production, land, is used only in the agricultural sector.

$offtext

parameter
    vnd(j,r)    Demand for land
    vns(i,r)    Supply of land
    vns0(i,r)   Supply of land
    ntax0(i,r)  Tax on land input
    ntax(i,r)   Tax on land input
    plnd0(i,r)  Reference price of land
;
vnd(j,r) = vfm("lnd",j,r);
vfm("lnd",j,r) = 0;
ntax0(j,r) = rtf("lnd",j,r);
ntax(j,r) = ntax0(j,r);
rtf("lnd",j,r) = 0;
display vnd, ntax0;

vns0(j,r) = vnd(j,r);
vns(j,r) = vns0(j,r);
display vns0, vns;

plnd0(j,r) = 1 + ntax0(j,r);
display plnd0;

*       ----------------------------------------------------------------------
display "@@ Labor supply";
parameters
    vld(i,r)    Benchmark labor demand by sector
    lab_inc(r)  Value of labour income
    end_l(r)    Benchmark labor endowment
    ltax(r )    Benchmark tax on labor (net base)
    pl0(r)      Reference price for labor
;
*       ----------------------------------------------------------------------
*       Labor, leisure for regions other than Japan:

*       Benchmark tax on labor (net base)
ltax(r)$dve(r) = 0.4;
ltax(r)$(not dve(r)) = 0.2;

*       Base year labor demand by sector:
vld(i,r) = vfm("lab",i,r)*(1+rtf0("lab",i,r)) / (1 + ltax(r));

*       Value of labour income:
lab_inc(r) = sum(i, vld(i,r));

*       Benchmark labor endowment.
end_l(r) = lab_inc(r);

*       ----------------------------------------------------------------------
*       Labor and leisure for Japan:
*       Benchmark tax on labor in Japan:
ltax(r)$jpn(r) = %ltax_jpn% / 100;
display ltax;

*       Base year labor demand by sector:
vld(i,r)$jpn(r) = vfm("lab",i,r)*(1+rtf0("lab",i,r)) / (1 + ltax(r));

*       Value of labour income:
lab_inc(r)$jpn(r) = sum(i, vld(i,r));

*       Benchmark labor endowment:
end_l(r)$jpn(r) = lab_inc(r);

display lab_inc, end_l;

pl0(r) = (1 + ltax(r));
display pl0;

*       ------------------------------------------------------------
display "@@ Capital stock";
$ontext
Capital stock
+ Natural resources in sectors other than the fossil fuel sector would be aggregated into capital.

$offtext
*       Benchmark factor demand:
parameter
    vkd(i,r)    Benchmark capital demand
    temp_tax
    ktax(i,r)   Tax on capital
    ktax0(i,r)  Tax on capital
    rk0(i,r)    Reference price for capital
    end_k(r)    Benchmark capital endowment
    end_k0(r)   Benchmark capital endowment
    ;
vkd(i,r) = vfm("cap",i,r) + vfm("res",i,r);
temp_tax(i,r) = rtf("cap",i,r)*vfm("cap",i,r) + rtf("res",i,r)*vfm("res",i,r);

ktax0(i,r)$vkd(i,r) = temp_tax(i,r) / vkd(i,r);
ktax(i,r) = ktax0(i,r);
display ktax, ktax0;

end_k0(r) = sum(i, vkd(i,r));
display end_k0;

end_k(r) = end_k0(r);
display end_k;

rk0(i,r) = 1 + ktax0(i,r);
display rk0;

*       Utility and lump-sum tax:
parameter
    vu(r)       Benchmark utility
    vlump(r)    Benchmark implicit lump-sum tax
;
*       The amount of lump-sum tax is derived as a residual (= income - expenditure).
vlump(r) =
    end_k(r)
    + end_l(r)
    + sum(j, vns0(j,r))
    + sum(j, vrs0(j,r))
    + vb(r)
    - vpm(r)
    - vinv(r)
    ;
display vlump;

*       Benchmark utility:
vu(r) = vpm(r);
display vu;

*       ----------------------------------------------------------------------
*       Elasticity of substitution
parameter
    sig_ec       EOS between energy and non-energy consumption
    sig_egc      EOS for energy consumption
    sig_nec      EOS for non-energy consumption
    sig_klem(i)  EOS for KLEM
    sig_kle(i)   EOS for KLE
    sig_kl(i)    EOS for KL
    sig_eg       EOS for energy aggregation in production
    sig_a(i)     Armington elasticity
    sig_m(i)     EOS between import goods
;
* gams-include-file: .\data\eos_cbam_18x17_gtap10ingams.gms
$include %eos_file%

display sig_ec, sig_egc, sig_nec;
display sig_kle, sig_kl;
display sig_a, sig_m;

*       ----------------------------------------------------------------------
*       Check data:
display "@@ Check data:";

parameter
    chk_vlabt           Labor tax revenue
    chk_vlumpt          Lump-sum tax revenue
    chk_votht           Other taxe revenue
    chk_vtax            Total tax revenue
    chk_gov             "Gov income - gov. expenditure = 0"
;
*       Labor tax:
chk_vlabt("v",r) = ltax(r) * sum(i, vld(i,r));

*       Lump-sum tax:
chk_vlumpt("v",r) = vlump(r);

*       Other tax:
chk_votht("v",r) =
*       Output tax
    sum(j, rto(j,r)*vom(j,r))
*       Tax for land for agricultural production:
    + sum(j, ntax(j,r)*vnd(j,r))
*       Tax for natural resource for fossil fuel production:
    + sum(xe, rtax(xe,r)*vrd(xe,r))
*       Capital tax:
    + sum(j, ktax0(j,r)*vkd(j,r))
*       Intermediate input tax:
    + sum((i,j)$vdfm(i,j,r), rtfd(i,j,r)*vdfm(i,j,r))
    + sum((i,j)$vifm(i,j,r), rtfi(i,j,r)*vifm(i,j,r))
*       Tax on consumption demand:
    + sum(i$vdpm(i,r), rtpd(i,r)*vdpm(i,r))
    + sum(i$vipm(i,r), rtpi(i,r)*vipm(i,r))
*       Tax on government demand:
    + sum(i$vdgm(i,r), rtgd(i,r)*vdgm(i,r))
    + sum(i$vigm(i,r), rtgi(i,r)*vigm(i,r))
*       Tax on investment demand:
    + sum(i$vdim(i,r), rtid(i,r)*vdim(i,r))
    + sum(i$viim(i,r), rtii(i,r)*viim(i,r))
*       Export subsidy
    - sum((i,s)$vxmd(i,r,s), rtxs(i,r,s)*vxmd(i,r,s))
* *       Tariff
    + sum((i,s)$vxmd(i,s,r),
        rtms(i,s,r)*(1-rtxs(i,s,r))*vxmd(i,s,r))
    + sum((i,s,j)$vtwr(j,i,s,r), rtms(i,s,r)*vtwr(j,i,s,r))
    ;
chk_votht("v","sum") = sum(r, chk_votht("v",r));

*       All tax revenue:
chk_vtax("v",r) = chk_vlabt("v",r) + chk_vlumpt("v",r) + chk_votht("v",r);

chk_gov("v",r) = chk_vtax("v",r) - vgm(r);
chk_gov("v","sum") = sum(r, chk_gov("v",r));

display chk_vlabt, chk_vlumpt, chk_votht, chk_vtax, chk_gov;

abort$(smax(r, round(abs(chk_gov("v",r)), 4))) "Inconsistency in the dataset", chk_gov;

parameters
    chk_exp_tax;

chk_exp_tax(r,"v") = sum((i,s)$vxmd(i,r,s), rtxs(i,r,s)*vxmd(i,r,s));
display chk_exp_tax;

*       Reverse the sign of rtxs
rtxs(i,s,r) = - rtxs(i,s,r);
display rtxs;

*       ----------------------------------------------------------------------
display "@ Setting about the policy";

*       ----------------------------------------------------------------------
display "@@ Setting for CBAM";

set
    cba_m_sec(i,s,r)    "Sectors covered by CBAM (imports)"
    cba_x_sec(i,r,s)    "Sectors covered by CBAM (exports)"
    cap_reg(r)          "Regions with emission regulations"
    cba_m_reg(s,r)      "Regions covered by CBAM (imports)"
    cba_x_reg(r,s)      "Regions covered by CBAM (exports)"
;
parameter
    fl_ctax             "Non-zero -> carbon tax, Zero -> C&T"
    ctax_rate_target(r) "Target carbon tax rate ($/tCO2), which is used in carbon tax rate"
    ctax_rate           "Target carbon tax rate ($/tCO2), which is used in carbon tax rate"
    rd_rate(r)          "Reduction rate (%), which is used in C&T"
    alloc_co2(*,r)      "Amount of free allocation"
;

cba_m_reg(s,r) = no;
cba_x_reg(r,s) = no;
ctax_rate(r) = 0;

parameters
    leak_reg(r)
;
leak_reg(r) = no;

*       Policy instrument.
* gams-include-file: .\scenarios\pol_inst_default.gms
$include %pol_inst_file%
display fl_ctax, leak_reg, cba_m_reg, cba_x_reg, cap_reg, rd_rate, ctax_rate_target;

*       Amount of free allocation
alloc_co2(i,r) = 0;
display alloc_co2;

$ontext
fl_lump(r)      If this is yes, lump-sum rebate
fl_cbam(i,s,r): Non-zero if a CBAM is applied to imports of good i from region s to region r.
fl_cbax(i,r,s): Non-zero if a CBAM is applied to exports of good i from region r to region s.
$offtext

set
    fl_lump(r)          "Nonzero → Lump-sum transfer"
    fl_cbam(i,r,s)      "Nonzero → CBAM applied to imports"
    fl_cbax(i,r,s)      "Nonzero → CBAM applied to exports"
;
parameter
    fl_cbafu            "Nonzero → CBAM based on CO₂ content calculated in the exporting country"
    fl_cba_bm           "Nonzero → Benchmark emission coefficients used in CBAM calculations"
    fl_cba_demi         "Nonzero → Only direct emissions considered"
    co2int              "Benchmark CO2 intensity (direct + indirect, CO2 emissions/output)"
    co2int_d            "Benchmark CO2 intensity (direct, CO2 emissions/output)"
    co2int_id           "Benchmark CO2 intensity (indirect, CO2 emissions/output)"
    shely0(*,r)         "Demand share of electricity"
    co2int_ely          "CO2 intensity of electricity exported (CO2 emissions/export)"
;
$macro mac_reset_flag \
    fl_lump(r) = no; \
    fl_cbam(i,r,s) = no; \
    fl_cbax(i,r,s) = no; \
    fl_cbafu = 0; \
    fl_cba_bm = 0; \
    fl_cba_demi = 0; \
    cba_m_sec(i,s,r) = no; \
    cba_x_sec(i,r,s) = no; \

mac_reset_flag;

*       Sectoral share of electricity consumption.
shely0(i,r) = 0;
shely0(i,r)$vom("ely",r) = vdfm("ely",i,r) / vom("ely",r);
shely0("HH",r)$vom("ely",r) = vdpm("ely",r) / vom("ely",r);
shely0("exp",r)$vom("ely",r) = sum(s, vxmd("ely",r,s)) / vom("ely",r);
display shely0;

parameter
    temp_co2t(*,r)      "Sectoral CO2 emission (direct + indirect)"
    temp_co2d(*,r)      "Sectoral CO2 emission (direct)"
    temp_co2id(*,r)     "Sectoral CO2 emission (indirect)"
    temp_co2_ely(r)     "CO2 emissions from electricity generation for export"
;
temp_co2d(i,r) = sum(en, co2f(en,i,r)) + co2p(i,r)$fl_proc;
temp_co2id(i,r) = shely0(i,r) * sum(en, co2f(en,"ely",r));
temp_co2t(i,r)$(not ely(i)) = temp_co2d(i,r) + temp_co2id(i,r);

temp_co2d("HH",r) = sum(en, co2h(en,r));
temp_co2id("HH",r) = shely0("HH",r) * sum(en, co2f(en,"ely",r));
temp_co2t("HH",r) = temp_co2d("HH",r) + temp_co2id("HH",r);
temp_co2t("sum",r) = sum(i, temp_co2t(i,r)) + temp_co2t("HH",r);

display temp_co2d, temp_co2id, temp_co2t;

temp_co2_ely(r) = temp_co2d("ely",r) * shely0("exp",r);
display temp_co2_ely;

*	Ratio of emissions and output.
co2int(i,r)$vom(i,r) = temp_co2t(i,r) / vom(i,r);
co2int_d(i,r)$vom(i,r) = temp_co2d(i,r) / vom(i,r);
co2int_id(i,r)$vom(i,r) = temp_co2id(i,r) / vom(i,r);

co2int("HH",r) = temp_co2t("HH",r) / vpm(r);
co2int_d("HH",r) = temp_co2d("HH",r) / vpm(r);
co2int_id("HH",r) = temp_co2id("HH",r) / vpm(r);

co2int(i,r) = co2int(i,r) + eps;
co2int_d(i,r) = co2int_d(i,r) + eps;
co2int_id(i,r) = co2int_id(i,r) + eps;

display co2int, co2int_d, co2int_id;

co2int_ely(r)$sum(s, vxmd("ely",r,s)) = temp_co2_ely(r) / sum(s, vxmd("ely",r,s));

display co2int_ely;

*       ------------------------------------------------------------

display "@ Check the benchmark data";
*       ------------------------------------------------------------
$include ./sub_check_bench_data.gms


parameter
    s_f                 Scale factor    / 1 /;

*       ----------------------------------------------------------------------
*       MPSGE model definition:
display "@ MPSGE model definition:";

* option sysout = on;

$ontext
$model:mrcge

*       Debug options for MPSGE
* $echop:.true.
* $datech:.true.
* $funlog:.true.

$sectors:
    U(r)                                ! Utility
    C(r)                                ! Private consumption
    GOV(r)                              ! Government consumption
    INV(r)                              ! Investment
    Y(i,r)$vom(i,r)                     ! Output
    M(i,r)$vim(i,r)                     ! Import activity
    X(i,r,s)$vxmd_(i,r,s)               ! Export activity
    YAF(i,j,r)$vafm(i,j,r)              ! Armington aggregation for intermediate inputs
    YAP(j,r)$vapm(j,r)                  ! Armington aggregation for private consumption
    YT(j)$vtw(j)                        ! International transportation services

$commodities:
    PU(r)                               ! Price index of utility
    PC(r)                               ! Private consumption price index
    PG(r)                               ! Government consumption price index
    PINV(r)                             ! Price index of investment
    PY(j,r)$vom(j,r)                    ! Domestic output price
    PM(j,r)$vim(j,r)                    ! Import price (inc. tariff and trans cost)
    PX(i,r,s)$vxmd_(i,r,s)              ! Export at world price
    PYAF(i,j,r)$vafm(i,j,r)             ! Armington composite price for intermediate inputs
    PYAP(j,r)$vapm(j,r)                 ! Armington composite price for private consumption
    PT(j)$vtw(j)                        ! Price of international transportation services
    PL(r)                               ! Wage rate
    RKR(r)                              ! Return to regional capital
    PLND(j,r)$vnd(j,r)                  ! Rental price of land
    PRES(j,r)$vrd(j,r)                  ! Price of natural resource
    PCO2(r)                             ! Carbon price - region specific

$consumers:
    M_H(r)                              ! Income of representative household
    M_G(r)                              ! Income of representative government

$auxiliary:
    LUMP(r)$fl_lump(r)                  ! Lump sum tax
    TMS(i,r,s)$fl_cbam(i,r,s)           ! Tariff rate including CBAM for imports
    TXS(i,r,s)$fl_cbax(i,r,s)           ! Export subsidiy rate including CBAM for export
    XI(i,r)$vom(i,r)                    ! CO2 intensity
    CO2T(i,r)$(not fl_cba_bm)           ! Total CO2 emissions from sector i (= direct + indirect emissions)
    CO2ID(i,r)$(vdfm("ely",i,r) and (not fl_cba_demi))     ! CO2 emissions from electricity (indrect emissions)
    SHELY(i,r)$(shely0(i,r) and (not fl_cba_demi))         ! Demand share of electricity
    TCO2(r)$(fl_ctax and ctax_rate(r))  ! Total CO2 emissions
    Z_YAFD_(i,j,r)$(vdfm(i,j,r)	and (not en(i)))	! Intermediate demand for domestic goods

*       ----------------------------------------------------------------------
*       Production function

*       Fossil fuel sectors（OIL, COA, GAS）
$prod:Y(xe,r)$vom(xe,r)  s:(sig_res(xe,r))  id:0
    o:PY(xe,r)       q:vom(xe,r)   a:M_G(r)  t:rto(xe,r)
*       Natural resource
    i:PRES(xe,r)     q:vrd(xe,r)   p:pres0(xe,r)  a:M_G(r)  t:rtax(xe,r)
*       Intermediate inputs
    i:PYAF(i,xe,r)   q:vafm(i,xe,r)  id:
*       Labor
    i:PL(r)          q:vld(xe,r)   p:pl0(r)       a:M_G(r)  t:ltax(r)      id:
*       Capital
    i:RKR(r)         q:vkd(xe,r)   p:rk0(xe,r)    a:M_G(r)  t:ktax(xe,r)  id:

*       Non-fossil fuel sectors except for P_C
$prod:Y(j,r)$(nr(j,r) and (not p_c(j)))  s:sig_klem(j)   kle(s):sig_kle(j)  kl(kle):sig_kl(j)  eg(kle):sig_eg
    o:PY(j,r)     q:vom(j,r)    a:M_G(r)  t:rto(j,r)  a:M_G(r)
*       Process emissions
    i:PCO2(r)$fl_proc           q:co2p(j,r)  p:1e-6
*       Intermediate inputs (non-energy)
    i:PYAF(i,j,r)$(not en(i))   q:vafm(i,j,r)        eg:$ely(i)
*       Intermediate inputs (energy)
    i:PYAF(en,j,r)              q:vafm(en,j,r)       eg:
*       Land
    i:PLND(j,r)   q:vnd(j,r)    p:plnd0(j,r)  kl:  a:M_G(r)  t:ntax(j,r)
*       Natural resource
    i:PRES(j,r)   q:vrd(j,r)    p:pres0(j,r)  kl:  a:M_G(r)  t:rtax(j,r)
*       Labor
    i:PL(r)       q:vld(j,r)    p:pl0(r)      kl:  a:M_G(r)  t:ltax(r)
*       Capital
    i:RKR(r)      q:vkd(j,r)    p:rk0(j,r)    kl:  a:M_G(r)  t:ktax(j,r)

*       Sector P_C
$prod:Y(j,r)$(vom(j,r) and p_c(j))  s:sig_klem(j)  kle(s):sig_kle(j)  kl(kle):sig_kl(j)  eg(kle):sig_eg
    o:PY(j,r)     q:vom(j,r)  a:M_G(r)  t:rto(j,r)  a:M_G(r)
*       Intermediate inputs (non-energy)
    i:PYAF(i,j,r)$(not en(i))   q:vafm(i,j,r)      eg:$ely(i)
*       Intermediate inputs (oil or coa)
    i:PYAF(i,j,r)$(oil(i) or coa(i))   q:vafm(i,j,r)
*       Intermediate inputs (gas)
    i:PYAF("gas",j,r)           q:vafm("gas",j,r)  eg:
*       Intermediate inputs (p_c)
    i:PYAF("p_c",j,r)           q:vafm("p_c",j,r)  eg:
*       Natural resource
    i:PRES(j,r)   q:vrd(j,r)    p:pres0(j,r)      kl: a:M_G(r)   t:rtax(j,r)
*       Labor
    i:PL(r)       q:vld(j,r)    p:pl0(r)          kl:  a:M_G(r)  t:ltax(r)
*       Capital
    i:RKR(r)      q:vkd(j,r)    p:rk0(j,r)  kl:  a:M_G(r)  t:ktax(j,r)

*       ----------------------------------------------------------------------
*       Armington aggregation

*       Non-energy goods
$prod:YAF(i,j,r)$vafm(i,j,r)$(not en(i))  s:sig_a(i)
    o:PYAF(i,j,r)  q:vafm(i,j,r)
    i:PY(i,r)      q:vdfm(i,j,r)  p:pintd0(i,j,r)  a:M_G(r)  t:rtfd(i,j,r)
    i:PM(i,r)      q:vifm(i,j,r)  p:pinti0(i,j,r)  a:M_G(r)  t:rtfi(i,j,r)

*       Energy goods
$prod:YAF(en,j,r)$vafm(en,j,r)  s:0   dm:sig_a(en)
    o:PYAF(en,j,r)     q:vafm(en,j,r)
    i:PCO2(r)          q:co2f(en,j,r)  p:1e-6
    i:PY(en,r)         q:vdfm(en,j,r)  p:pintd0(en,j,r)  a:M_G(r)  t:rtfd(en,j,r)  dm:
    i:PM(en,r)         q:vifm(en,j,r)  p:pinti0(en,j,r)  a:M_G(r)  t:rtfi(en,j,r)  dm:

*       ----------------------------------------------------------------------
*       International transport services (Cobb-Douglas function)
$prod:YT(j)$vtw(j)  s:1
    o:PT(j)       q:vtw(j)
    i:PY(j,r)     q:vst(j,r)

*       ----------------------------------------------------------------------
*       Final demand

*       Utility without saving
$prod:U(r)
    o:PU(r)             q:vu(r)
    i:PC(r)             q:vpm(r)

*       Private consumption
$prod:C(r)  s:sig_ec  c(s):sig_nec  e(s):sig_egc
    o:PC(r)        q:vpm(r)
    i:PYAP(i,r)    q:vapm(i,r)  c:$(not e(i))  e:$e(i)

*       Armington aggregation for private consumption (non-energy goods)
$prod:YAP(i,r)$vapm(i,r)$(not en(i))  s:sig_a(i)
    o:PYAP(i,r)    q:vapm(i,r)
    i:PY(i,r)      q:vdpm(i,r)   p:pcd0(i,r)  a:M_G(r) t:rtpd(i,r)
    i:PM(i,r)      q:vipm(i,r)   p:pci0(i,r)  a:M_G(r) t:rtpi(i,r)

*       Armington aggregation for private consumption (energy goods)
$prod:YAP(i,r)$vapm(i,r)$en(i)  s:0  dm:sig_a(i)
    o:PYAP(i,r)   q:vapm(i,r)
    i:PCO2(r)     q:co2h(i,r)   p:1e-6
    i:PY(i,r)     q:vdpm(i,r)   p:pcd0(i,r)  a:M_G(r)  t:rtpd(i,r)  dm:
    i:PM(i,r)     q:vipm(i,r)   p:pci0(i,r)  a:M_G(r)  t:rtpi(i,r)  dm:

*       ----------------------------------------------------------------------
*       Export activity
$prod:X(i,r,s)$vxmd_(i,r,s)
    o:PX(i,r,s) q:vxmd_(i,r,s)
    i:PY(i,r)   q:vxmd(i,r,s)   p:pvx(i,r,s)
+   a:M_G(r)    t:rtxs(i,r,s)$(not fl_cbax(i,r,s))  n:txs(i,r,s)$fl_cbax(i,r,s)

*       ----------------------------------------------------------------------
*       Import activity
$prod:M(i,r)$vim(i,r)   s:sig_m(i)  s.tl:0
    o:PM(i,r)    q:vim(i,r)
    i:PX(i,s,r)$vxmd_(i,s,r)   q:vxmd_(i,s,r)  p:pvxmd_(i,s,r)  s.tl:
+   a:M_G(r)     t:rtms(i,s,r)$(not fl_cbam(i,s,r))  n:tms(i,s,r)$fl_cbam(i,s,r)
    i:PT(j)#(s)  q:vtwr(j,i,s,r)  p:pvtwr(i,s,r)  a:M_G(r)  t:rtms(i,s,r)  s.tl:

*       ----------------------------------------------------------------------
*       Investment
$prod:INV(r)  s:0  i.tl:sig_a(i)
    o:PINV(r)   q:vinv(r)
    i:PY(i,r)   q:vdim(i,r)  p:(1+rtid0(i,r))  a:M_G(r)  t:rtid(i,r)  i.tl:
    i:PM(i,r)   q:viim(i,r)  p:(1+rtii0(i,r))  a:M_G(r)  t:rtii(i,r)  i.tl:

*       ----------------------------------------------------------------------
*       Government consumption
$prod:GOV(r)  s:0  i.tl:sig_a(i)
    o:PG(r)     q:vgm(r)
    i:PY(i,r)   q:vdgm(i,r)  p:(1+rtgd0(i,r))  a:M_G(r)  t:rtgd(i,r)  i.tl:
    i:PM(i,r)   q:vigm(i,r)  p:(1+rtgi0(i,r))  a:M_G(r)  t:rtgi(i,r)  i.tl:

*       ----------------------------------------------------------------------
*       Income of private household
$demand:m_h(r)
    d:pu(r)                q:vu(r)
    e:PINV(r)		   q:(-s_f*vinv(r))
    e:PLND(j,r)            q:(s_f*vns(j,r))
    e:PRES(j,r)            q:(s_f*vrs(j,r))
    e:PL(r)		   q:(s_f*end_l(r))
    e:RKR(r)               q:(s_f*end_k(r))
    e:PC(r)                q:(-s_f*vlump(r))
    e:PC(rnum)             q:(s_f*vb(r))
    e:PC(r)$fl_lump(r)     q:1      r:LUMP(r)

*       ----------------------------------------------------------------------
*       Income of government
$demand:m_g(r)
    d:pg(r)                q:vgm(r)
    e:PC(r)                q:(s_f*vlump(r))
    e:PC(r)$fl_lump(r)     q:(-1)    r:LUMP(r)
    e:PCO2(r)$(not fl_ctax)          q:co2lim(r)
    e:PCO2(r)$(fl_ctax and ctax_rate(r))        q:co2bench(r)   r:TCO2(r)
    e:PCO2(r)$(fl_ctax and (not ctax_rate(r)))  q:(co2bench(r)*10)

*       ----------------------------------------------------------------------
*       Lump-sum tax or lump-sum transfer

*       Lump-sum transfer
$constraint:LUMP(r)$fl_lump(r)
    M_G(r) =e= PG(r) * vgm(r) * s_f;

*       ----------------------------------------------------------------------
*       Constraint on total CO2 emissions for carbon tax policy
$constraint:TCO2(r)$(fl_ctax and ctax_rate(r))
    PCO2(r) =e= PC(r) * ctax_rate(r) / 1000;

*       ----------------------------------------------------------------------
*       Variables for CBA

*       CO2-output ratio
$constraint:XI(i,r)$vom(i,r)
    XI(i,r) =e=
    ((CO2T(i,r) / (vom(i,r)*Y(i,r)))$(not fl_cba_bm)
    + (co2int(i,r)$(not fl_cba_demi) + co2int_d(i,r)$fl_cba_demi)$fl_cba_bm
    )$(not ely(i))
    +
    ((CO2T(i,r) / (vom(i,r)*Y(i,r)))$(not fl_cba_bm)
    + co2int_d(i,r)$fl_cba_bm
    )$ely(i)
;
*       Tariff rate including CBAM for imports
$constraint:TMS(i,s,r)$fl_cbam(i,s,r)
    TMS(i,s,r) * PX(i,s,r) =e=
    rtms(i,s,r) * PX(i,s,r)
    + PCO2(r) * (XI(i,r)$(not fl_cbafu) + XI(i,s)$fl_cbafu);

*       Export subsidiy rate including CBAM for export
$constraint:TXS(i,s,r)$fl_cbax(i,s,r)
    TXS(i,s,r) * PY(i,s) =e= rtxs(i,s,r) * PY(i,s) - PCO2(s) * XI(i,s);

*       Demand share of electricity:
$constraint:SHELY(i,r)$(shely0(i,r) and (not fl_cba_demi))
    SHELY(i,r) * shely0(i,r) * (vom("ely",r)*Y("ely",r)) =e= Z_YAFD_("ely",i,r);

*       CO2 emissions from electricity (indrect emissions)
$constraint:CO2ID(i,r)$(shely0(i,r) and (not fl_cba_demi))
    CO2ID(i,r) =e=
    SHELY(i,r) * shely0(i,r) * sum(en$co2f(en,"ely",r), YAF(en,"ely",r) * co2f(en,"ely",r));

*       Total CO2 emissions from sector i
$constraint:CO2T(i,r)$(not fl_cba_bm)
    CO2T(i,r) =e=
    sum(en$co2f(en,i,r), YAF(en,i,r) * co2f(en,i,r))
    + (sum(j$co2p(j,r), Y(j,r)*co2p(j,r)))$fl_proc
    + CO2ID(i,r)$((not ely(i)) and vdfm("ely",i,r) and (not fl_cba_demi));

$constraint:Z_YAFD_(i,j,r)$vdfm(i,j,r)
    Z_YAFD_(i,j,r) =e= YAF(i,j,r) * vdfm(i,j,r)
    * (PYAF(i,j,r) / ((1+rtfd(i,j,r))*PY(i,r) / pintd0(i,j,r)))**(sig_a(i));

*       ----------------------------------------------------------------------
*       Variables for reporting

$report:
    v:Z_Y(j,r)$vom(j,r)         o:PY(j,r)       prod:Y(j,r)     ! Output
    v:Z_YAF(i,j,r)$vafm(i,j,r)  i:PYAF(i,j,r)   prod:Y(j,r)     ! Intermediate demand
    v:Z_LD(j,r)$vld(j,r)        i:PL(r)         prod:Y(j,r)     ! Labor demand
    v:Z_KD(j,r)$vkd(j,r)        i:RKR(r)        prod:Y(j,r)     ! Capital demand (immobile int.)
    v:Z_RD(j,r)$vrd(j,r)        i:PRES(j,r)     prod:Y(j,r)     ! Resource demand
    v:Z_ND(j,r)$vnd(j,r)        i:PLND(j,r)     prod:Y(j,r)     ! Land demand

*       Demand for domestic and import goods
$report:
    v:Z_YAFD(i,j,r)$vdfm(i,j,r)  i:PY(i,r)   prod:YAF(i,j,r)    ! Int. demand for domestic goods
    v:Z_YAFI(i,j,r)$vifm(i,j,r)  i:PM(i,r)   prod:YAF(i,j,r)    ! Int. demand for import goods

*       Final demand:
$report:
    v:Z_CON(r)   o:PC(r)         prod:C(r) 			! Private consumption
    v:Z_INV(r)   o:PINV(r)       prod:INV(r)                    ! Investment
    v:Z_GOV(r)   o:PG(r)         prod:GOV(r)                    ! Government exp.
    v:Z_IMP_a(i,r)$vim(i,r)      o:PM(i,r)     prod:M(i,r)      ! Aggreatre import of goods i
    v:Z_EXP_(i,r,s)$vxmd_(i,r,s) o:PX(i,r,s)   prod:X(i,r,s)    ! Export of goods ifrom region r to s
    v:Z_EXP(i,r,s)$vxmd(i,r,s)   i:PY(i,r)     prod:X(i,r,s)    ! Export of goods ifrom region r to s
    v:Z_IMP(i,s,r)$vxmd(i,s,r)   i:PX(i,s,r)   prod:M(i,r)      ! Import
    v:Z_VST(j,r)$vst(j,r)        i:PY(j,r)     prod:YT(j)       ! Export to international trans. sec

$report:
    v:Z_YAPD(i,r)$vdpm(i,r)    i:PY(i,r)    prod:YAP(i,r) 	! Consumption demand (dom)
    v:Z_YAPI(i,r)$vipm(i,r)    i:PM(i,r)    prod:YAP(i,r)	! Consumption demand (imp)
    v:Z_YAGD(i,r)$vdgm(i,r)    i:PY(i,r)    prod:GOV(r)		! Government demand (dom)
    v:Z_YAGI(i,r)$vigm(i,r)    i:PM(i,r)    prod:GOV(r)		! Government demand (imp)
    v:Z_YAID(i,r)$vdim(i,r)    i:PY(i,r)    prod:INV(r)		! Investment demand (dom)
    v:Z_YAII(i,r)$viim(i,r)    i:PM(i,r)    prod:INV(r)		! Investment demand (imp)

$offtext
$sysinclude mpsgeset mrcge

*       ----------------------------------------------------------------------
display "@@ Initial values and lower values";

PCO2.l(r) =  0;

TCO2.l(r) = 1;
TCO2.lo(r) = 1e-6;

*       Initial values for lump-sum tax variables:
LUMP.lo(r) = -inf;
LUMP.up(r) = +inf;
LUMP.l(r) = 0;

*       Tariff and export subsidy rates including CBA:
TMS.l(i,r,s) = rtms(i,r,s);
TXS.l(i,r,s) = rtxs(i,r,s);
TMS.lo(i,r,s) = -inf;
TXS.lo(i,r,s) = -inf;

Z_Y.l(i,r) = vom(i,r);
Z_YAFD.l(i,j,r) = vdfm(i,j,r);
Z_YAFD_.l(i,j,r) = vdfm(i,j,r);

*       Demand share of electricity:
SHELY.l(i,r) = 1;

*       Indirect CO2 emissions:
CO2ID.l(i,r) =
    SHELY.l(i,r) * shely0(i,r) * sum(en$co2f(en,"ely",r), co2f(en,"ely",r));

*       Total CO2 emissions:
CO2T.l(i,r) =
    CO2ID.l(i,r)$(not fl_cba_demi)
    + sum(en$co2f(en,i,r), co2f(en,i,r))
    + (sum(j$co2p(j,r), co2p(j,r)))$fl_proc;

*       CO2 intensity (CO2/output)
XI.l(i,r)$vom(i,r) = (CO2T.l(i,r) / vom(i,r))$(not fl_cba_bm) + co2int(i,r)$fl_cba_bm;

*       ------------------------------------------------------------
display "@ Simulation scenarios";

set sall        All scenarios   /
    bm,
    ncba,
    wcbam,
    cbam2,
    cbam3,
    cbam4,
    cbam5,
    cbam6
    /
    sbm(sall)  / bm /
    ssol(sall)  The list of scenarios solved /
    bm             Benchmark equilibrium
$if not %s_ncba%==0     ncba                   No CBA
$if not %wcbam%==0	wcbam
$if not %cbam2%==0	cbam2
$if not %cbam3%==0	cbam3
$if not %cbam4%==0	cbam4
$if not %cbam5%==0	cbam5
$if not %cbam6%==0	cbam6
/
    ssol_(sall)
    sbm(sall)           Benchmark equilibrium
    cur_s(sall)         Current scenario
;
display ssol;
cur_s(sall) = no;

ssol_(ssol) = yes;
ssol_("bm") = no;
display ssol_;

sbm("bm") = yes;

*       ------------------------------------------------------------
display "@ Parameters for reporting";

*       ------------------------------------------------------------
$ontext

$offtext
$include .\sub_parameters_report.gms


*       ----------------------------------------------------------------------
display "@ Solve model";

*       ----------------------------------------------------------------------
display "@@ Benchmark replication.";

*       ----------------------------------------------------------------------
*       Policy choice for benchmark replication:

*       Reset of flags.
mac_reset_flag;

$ontext
In the benchmark equilibrium,
+ No emissions regulation.
+ No CBAM.
$offtext
fl_lump(r) = yes;

*       In the benchmark equilibrium, no emissions regulations.
co2lim(r) =  co2bench(r) * 10;

mrcge.optfile = 1;
mrcge.workspace = 1000;
mrcge.iterlim = 0;
$include mrcge.gen
solve mrcge using mcp;
chk_objval("bm") = mrcge.objval;
$if not %br_only%==0 $goto end

*       ----------------------------------------------------------------------
display "@@ Cleanup calculation.";

mrcge.iterlim = 100000;
$include mrcge.gen
solve mrcge using mcp;
$if not %cc_only%==0 $goto end

*       Export parameters.
loop(ssol$sbm(ssol),
$include sub_output_results.gms
);

display l_ely_sh, l_co2_ely, l_exp_sh;

parameters
    chk_trade_alt;

chk_trade_alt(r,i,"dom","1")
    = sum(j, z_yafd.l(i,j,r))
    + z_yapd.l(i,r) + z_yagd.l(i,r) + z_yaid.l(i,r);
chk_trade_alt(r,i,"dom","2")
    = z_y.l(i,r) - sum(s, z_exp.l(i,r,s)) - z_vst.l(i,r);
chk_trade_alt(r,i,"dom","1-2")
    = chk_trade_alt(r,i,"dom","1") - chk_trade_alt(r,i,"dom","2");
chk_trade_alt(r,i,"dom","1-2") = round(chk_trade_alt(r,i,"dom","1-2"), 6);
display chk_trade_alt;

$if %scale_shock%==0 $goto sc_end
*       ----------------------------------------------------------------------
display "@@ Scale shock experiments:";

s_f = 1 + %scale_shock% / 100;
$include mrcge.gen
solve mrcge using mcp;
s_f = 1;

$if not %scale_shock%==0 $goto end
$label sc_end

*       ----------------------------------------------------------------------
display "@ Carbon regulatoins";

loop(ssol$(not sbm(ssol)),

    cur_s(sall) = no;
    cur_s(ssol) = yes;

*       Load settings for the regulation method. Varies by scenario.
* gams-include-file: ./scenarios/pol_scenario_default.gms
$include %pol_sce_file%
    display fl_lump, alloc_co2, cba_m_sec, cba_x_sec, fl_cbax, fl_cbam, fl_cbafu;

*       Initialization of variables.
$include sub_initialize.gms

*       Carbon tax rates
    ctax_rate(r) = ctax_rate_target(r) * 0.5;
    display ctax_rate;

*       C&T Scenario.
    co2lim(r)$(not rd_rate(r)) = co2bench(r) * 10;
    co2lim(r)$rd_rate(r) = co2bench(r) * (1 - 0.5 * rd_rate(r)/100);
    display co2lim;

    option solprint = off;
$include mrcge.gen
    solve mrcge using mcp;
    option solprint = on;

*       Carbon tax rates
    ctax_rate(r) = ctax_rate_target(r);
    display ctax_rate;

*       C&T Scenario.
    co2lim(r)$(not rd_rate(r)) = co2bench(r) * 10;
    co2lim(r)$rd_rate(r) = co2bench(r) * (1 - rd_rate(r)/100);
    display co2lim;

*       Solve the model.
$include mrcge.gen
    solve mrcge using mcp;

*	Export results to parameters.
$include sub_output_results.gms

);

if(fl_debug,

    display l_co2_use, l_co2_so, l_co2_t, l_co2_leak_sec, l_co2_leak;
    display l_exp_c, l_imp_c, l_nexp_c, l_exp_r, l_ex_sh, l_exp, l_imp;
    display l_exp_eur_c;
    display l_u, l_c, l_lsr, l_emp, l_inv, l_gov, l_gdp, l_pco2, l_inc;
    display l_y, l_pene_ex;
    display l_cbam, l_cbax, l_cbarev, l_tot;
);

*       ----------------------------------------------------------------------
display "@ Calculate parameters for reporting:";

set     reg_    / cap_reg, ncap_reg, world /;

*       ------------------------------------------------------------
*       CO2 emissions

*       CO2 emissions
pc_co2(en,j,r,ssol_)$l_co2("ncba",en,j,r)
    = 100 * (l_co2(ssol_,en,j,r) / l_co2("ncba",en,j,r) - 1);

*       Total CO2 emissions (MtCO2)
d_co2_t(r,ssol_)$l_co2_t(r,"ncba")
    = l_co2_t(r,ssol_) - l_co2_t(r,"ncba");
d_co2_t("World",ssol_)$l_co2_t("World","ncba")
    = l_co2_t("World",ssol_) - l_co2_t("World","ncba");
d_co2_t("cap_reg",ssol_)$l_co2_t("cap_reg","ncba")
    = l_co2_t("cap_reg",ssol_) - l_co2_t("cap_reg","ncba");
d_co2_t("ncap_reg",ssol_)$l_co2_t("ncap_reg","ncba")
    = l_co2_t("ncap_reg",ssol_) - l_co2_t("ncap_reg","ncba");
d_co2_t("leak_reg",ssol_)$l_co2_t("leak_reg","ncba")
    = l_co2_t("leak_reg",ssol_) - l_co2_t("leak_reg","ncba");
d_co2_t("nleak_reg",ssol_)$l_co2_t("nleak_reg","ncba")
    = l_co2_t("nleak_reg",ssol_) - l_co2_t("nleak_reg","ncba");

*       Total CO2 emissions
pc_co2_t(r,ssol_)$l_co2_t(r,"ncba")
    = 100 * (l_co2_t(r,ssol_) / l_co2_t(r,"ncba") - 1);
pc_co2_t("World",ssol_)$l_co2_t("World","ncba")
    = 100 * (l_co2_t("World",ssol_) / l_co2_t("World","ncba") - 1);
pc_co2_t("cap_reg",ssol_)$l_co2_t("cap_reg","ncba")
    = 100 * (l_co2_t("cap_reg",ssol_) / l_co2_t("cap_reg","ncba") - 1);
pc_co2_t("ncap_reg",ssol_)$l_co2_t("ncap_reg","ncba")
    = 100 * (l_co2_t("ncap_reg",ssol_) / l_co2_t("ncap_reg","ncba") - 1);
pc_co2_t("leak_reg",ssol_)$l_co2_t("leak_reg","ncba")
    = 100 * (l_co2_t("leak_reg",ssol_) / l_co2_t("leak_reg","ncba") - 1);
pc_co2_t("nleak_reg",ssol_)$l_co2_t("nleak_reg","ncba")
    = 100 * (l_co2_t("nleak_reg",ssol_) / l_co2_t("nleak_reg","ncba") - 1);

*       Total CO2 emissions
pc_co2_t_(r,ssol_)$l_co2_t(r,"bm")
    = 100 * (l_co2_t(r,ssol_) / l_co2_t(r,"bm") - 1);
pc_co2_t_("World",ssol_)$l_co2_t("World","bm")
    = 100 * (l_co2_t("World",ssol_) / l_co2_t("World","bm") - 1);
pc_co2_t_("cap_reg",ssol_)$l_co2_t("cap_reg","bm")
    = 100 * (l_co2_t("cap_reg",ssol_) / l_co2_t("cap_reg","bm") - 1);
pc_co2_t_("ncap_reg",ssol_)$l_co2_t("ncap_reg","bm")
    = 100 * (l_co2_t("ncap_reg",ssol_) / l_co2_t("ncap_reg","bm") - 1);
pc_co2_t_("leak_reg",ssol_)$l_co2_t("leak_reg","bm")
    = 100 * (l_co2_t("leak_reg",ssol_) / l_co2_t("leak_reg","bm") - 1);
pc_co2_t_("nleak_reg",ssol_)$l_co2_t("nleak_reg","bm")
    = 100 * (l_co2_t("nleak_reg",ssol_) / l_co2_t("nleak_reg","bm") - 1);

*       CO2 emissions by use (MtCO2)
d_co2_use(i,r,ssol_) = l_co2_use(r,i,ssol_) - l_co2_use(r,i,"ncba");
d_co2_use(ssec,r,ssol_) = l_co2_use(r,ssec,ssol_) - l_co2_use(r,ssec,"ncba");

pc_co2_use(r,j,ssol_)$l_co2_use(r,j,"ncba")
    = 100 * (l_co2_use(r,j,ssol_) / l_co2_use(r,j,"ncba") - 1);
pc_co2_use(r,ssec,ssol_)$l_co2_use(r,ssec,"ncba")
    = 100 * (l_co2_use(r,ssec,ssol_) / l_co2_use(r,ssec,"ncba") - 1);

*       CO2 emissions by source (MtCO2)
d_co2_so(r,en,ssol_) = l_co2_so(r,en,ssol_) - l_co2_so(r,en,"ncba");
d_co2_so(r,"proc",ssol_) = l_co2_so(r,"proc",ssol_) - l_co2_so(r,"proc","ncba");
d_co2_so(r,"sum",ssol_) = l_co2_so(r,"sum",ssol_) - l_co2_so(r,"sum","ncba");

pc_co2_so(r,en,ssol_)$l_co2_so(r,en,"ncba")
    = 100 * (l_co2_so(r,en,ssol_) / l_co2_so(r,en,"ncba") - 1);
pc_co2_so(r,"proc",ssol_)$l_co2_so(r,"proc","ncba")
    = 100 * (l_co2_so(r,"proc",ssol_) / l_co2_so(r,"proc","ncba") - 1);
pc_co2_so(r,"sum",ssol_)$l_co2_so(r,"sum","ncba")
    = 100 * (l_co2_so(r,"sum",ssol_) / l_co2_so(r,"sum","ncba") - 1);

*       CO2 emissions by use in Japan
pc_co2_use_jpn(i,ssol_) = pc_co2_use(i,"jpn",ssol_);
*       CO2 emissions by use in Japan
pc_co2_use_jpn(ssec,ssol_) = pc_co2_use(ssec,"jpn",ssol_);
*       CO2 emissions by use in Japan
pc_co2_use_jpn(ssec,ssol_) = pc_co2_use(ssec,"jpn",ssol_);


*       ----------------------------------------------------------------------
*       Leakage rate.

*       Carbon leakage by sector.
d_co2_leak_sec(i,ssol_) =
    l_co2_leak_sec(ssol_,i,"nleak_reg") - l_co2_leak_sec("bm",i,"nleak_reg");
d_co2_leak_sec(ssec,ssol_) =
    l_co2_leak_sec(ssol_,ssec,"nleak_reg") - l_co2_leak_sec("bm",ssec,"nleak_reg");

*       Carbon leakage by region
d_co2_leak_reg(r,ssol_) = l_co2_t(r,ssol_) - l_co2_t(r,"bm");
d_co2_leak_reg("nleak_reg",ssol_) = sum(r$(not leak_reg(r)), d_co2_leak_reg(r,ssol_));
d_co2_leak_reg("leak_reg",ssol_) = sum(r$leak_reg(r), d_co2_leak_reg(r,ssol_));
d_co2_leak_reg("sum",ssol_) = sum(r, d_co2_leak_reg(r,ssol_));

*       Plus.
d_co2_leak("nleak_reg",ssol_) = l_co2_leak(ssol_,"nleak_reg") - l_co2_leak("bm","nleak_reg");
*       Minus.
d_co2_leak("leak_reg",ssol_) = l_co2_leak(ssol_,"leak_reg") - l_co2_leak("bm","leak_reg");
d_co2_leak("sum",ssol_) = d_co2_leak("leak_reg",ssol_) + d_co2_leak("nleak_reg",ssol_);

*       Leakage rate by region (%).
l_leak_rate_reg(r,ssol_)$((not leak_reg(r)) and sum(rr$leak_reg(rr), - d_co2_leak_reg(rr,ssol_)))
    = 100 * d_co2_leak_reg(r,ssol_)
    / sum(rr$leak_reg(rr), - d_co2_leak_reg(rr,ssol_));
l_leak_rate_reg("sum",ssol_) = sum(r$(not leak_reg(r)), l_leak_rate_reg(r,ssol_));

*       Total leakage rate (%).
l_leak_rate("Leakage_rate (%)",ssol_)$d_co2_leak("leak_reg",ssol_)
    = - 100 * (d_co2_leak("nleak_reg",ssol_) / d_co2_leak("leak_reg",ssol_));

display d_co2_leak_sec, d_co2_leak_reg, d_co2_leak, l_leak_rate_reg, l_leak_rate;

*       ------------------------------------------------------------
*       Trade

*       Change in net export by commodity.
d_nexp_c(r,i,ssol_) = l_nexp_c(r,i,ssol_) - l_nexp_c(r,i,"ncba");
d_nexp_c(r,ssec,ssol_) = l_nexp_c(r,ssec,ssol_) - l_nexp_c(r,ssec,"ncba");

pc_nexp_c(r,i,ssol_) = eps;
pc_nexp_c(r,ssec,ssol_) = eps;

pc_nexp_c(r,i,ssol_)$l_nexp_c(r,i,"ncba")
    = 100 * (l_nexp_c(r,i,ssol_) / l_nexp_c(r,i,"ncba") - 1) + eps;
pc_nexp_c(r,ssec,ssol_)$l_nexp_c(r,ssec,"ncba")
    = 100 * (l_nexp_c(ssol_,ssec,r) / l_nexp_c(r,ssec,"ncba") - 1) + eps;
pc_nexp_c(r,i,ssol_)$(l_nexp_c(r,i,ssol_) < 0.001) = na;
pc_nexp_c(r,ssec,ssol_)$(l_nexp_c(ssol_,ssec,r) < 0.001) = na;

*       Export by commodity
d_exp_c(r,i,ssol_) = l_exp_c(r,i,ssol_) - l_exp_c(r,i,"ncba");
d_exp_c(r,ssec,ssol_) = l_exp_c(r,ssec,ssol_) - l_exp_c(r,ssec,"ncba");

pc_exp_c(r,i,ssol_) = eps;
pc_exp_c(r,ssec,ssol_) = eps;
pc_exp_c(r,i,ssol_)$l_exp_c(r,i,"ncba")
    = 100 * (l_exp_c(r,i,ssol_) / l_exp_c(r,i,"ncba") - 1) + eps;
pc_exp_c(r,ssec,ssol_)$l_exp_c(r,ssec,"ncba")
    = 100 * (l_exp_c(r,ssec,ssol_) / l_exp_c(r,ssec,"ncba") - 1) + eps;
* pc_exp_c(r,i,ssol_)$(l_exp_c(r,i,ssol_) < 0.001) = na;
* pc_exp_c(r,ssec,ssol_)$(l_exp_c(ssol_,ssec,r) < 0.001) = na;

*       (Aggregate) import by commodity
d_imp_c(r,i,ssol_) = l_imp_c(r,i,ssol_) - l_imp_c(r,i,"ncba");
d_imp_c(r,ssec,ssol_) = l_imp_c(r,ssec,ssol_) - l_imp_c(r,ssec,"ncba");

pc_imp_c(r,i,ssol_) = eps;
pc_imp_c(r,ssec,ssol_) = eps;

pc_imp_c(r,i,ssol_)$l_imp_c(r,i,"ncba")
    = 100 * (l_imp_c(r,i,ssol_) / l_imp_c(r,i,"ncba") - 1) + eps;
pc_imp_c(r,ssec,ssol_)$l_imp_c(r,ssec,"ncba")
    = 100 * (l_imp_c(r,ssec,ssol_) / l_imp_c(r,ssec,"ncba") - 1) + eps;
* pc_imp_c(r,i,ssol_)$(l_imp_c(r,i,ssol_) < 0.001) = na;
* pc_imp_c(r,ssec,ssol_)$(l_imp_c(ssol_,ssec,r) < 0.001) = na;

d_exp_i_s_c(r,ssol) = d_exp_c(r,"i_s",ssol);
d_imp_i_s_c(r,ssol) = d_imp_c(r,"i_s",ssol);
d_nexp_i_s_c(r,ssol) = d_nexp_c(r,"i_s",ssol);
pc_exp_i_s_c(r,ssol) = pc_exp_c(r,"i_s",ssol);
pc_imp_i_s_c(r,ssol) = pc_imp_c(r,"i_s",ssol);
pc_nexp_i_s_c(r,ssol) = pc_nexp_c(r,"i_s",ssol);

*       Total export (excl. export to own regions)
pc_exp_(r,ssol_)$l_exp_("ncba",r) = 100 * (l_exp_(ssol_,r) / l_exp_("ncba",r) - 1);

*       Total import (excl. import from own regions)
pc_imp_(r,ssol_)$l_imp_("ncba",r) = 100 * (l_imp_(ssol_,r) / l_imp_("ncba",r) - 1);

*       Export by destination
d_exp_r(r,s,ssol_)$l_exp_r("ncba",r,s) = l_exp_r(ssol_,r,s) - l_exp_r("ncba",r,s);
d_exp_r(r,s,ssol_)$(l_exp_r(ssol_,r,s) < 0.001) = na;

pc_exp_r(r,s,ssol_)$l_exp_r("ncba",r,s)
    = 100 * (l_exp_r(ssol_,r,s) / l_exp_r("ncba",r,s) - 1) + eps;
pc_exp_r(r,s,ssol_)$(l_exp_r(ssol_,r,s) < 0.001) = na;

*       Export to EU and Non-EU
d_exp_eur(ssol_,r,"EUR")$l_exp_eur("ncba",r,"EUR") = l_exp_eur(ssol_,r,"EUR") - l_exp_eur("ncba",r,"EUR");
d_exp_eur(ssol_,r,"NEUR")$l_exp_eur("ncba",r,"NEUR") = l_exp_eur(ssol_,r,"NEUR") - l_exp_eur("ncba",r,"NEUR");
d_exp_eur(ssol_,r,"EUR") $(l_exp_eur(ssol_,r,"EUR") < 0.001) = na;
d_exp_eur(ssol_,r,"NEUR") $(l_exp_eur(ssol_,r,"NEUR") < 0.001) = na;

pc_exp_eur(ssol_,r,"EUR")$l_exp_eur("ncba",r,"EUR")
    = 100 * (l_exp_eur(ssol_,r,"EUR") / l_exp_eur("ncba",r,"EUR") - 1) + eps;
pc_exp_eur(ssol_,r,"NEUR")$l_exp_eur("ncba",r,"NEUR")
    = 100 * (l_exp_eur(ssol_,r,"NEUR") / l_exp_eur("ncba",r,"NEUR") - 1) + eps;
pc_exp_eur(ssol_,r,"EUR") $(l_exp_eur(ssol_,r,"EUR") < 0.001) = na;
pc_exp_eur(ssol_,r,"NEUR") $(l_exp_eur(ssol_,r,"NEUR") < 0.001) = na;

*       Export to EU and Non-EU
d_exp_eur_c(ssol_,r,i,"EUR")$l_exp_eur_c("ncba",r,i,"EUR")
    = l_exp_eur_c(ssol_,r,i,"EUR") - l_exp_eur_c("ncba",r,i,"EUR") + eps;
d_exp_eur_c(ssol_,r,i,"NEUR")$l_exp_eur_c("ncba",r,i,"NEUR")
    = l_exp_eur_c(ssol_,r,i,"NEUR") - l_exp_eur_c("ncba",r,i,"NEUR") + eps;

pc_exp_eur_c(ssol_,r,i,"EUR")$l_exp_eur_c("ncba",r,i,"EUR")
    = 100 * (l_exp_eur_c(ssol_,r,i,"EUR") / l_exp_eur_c("ncba",r,i,"EUR") - 1) + eps;
pc_exp_eur_c(ssol_,r,i,"NEUR")$l_exp_eur_c("ncba",r,i,"NEUR")
    = 100 * (l_exp_eur_c(ssol_,r,i,"NEUR") / l_exp_eur_c("ncba",r,i,"NEUR") - 1) + eps;
pc_exp_eur_c(ssol_,r,i,"EUR")$(l_exp_eur_c(ssol_,r,i,"eur") < 0.001) = na;
pc_exp_eur_c(ssol_,r,i,"NEUR")$(l_exp_eur_c(ssol_,r,i,"neur") < 0.001) = na;

*       Import by
pc_imp_r(r,s,ssol_)$l_imp_r("ncba",r,s)
    = 100 * (l_imp_r(ssol_,r,s) / l_imp_r("ncba",r,s) - 1);
pc_imp_r("sum",s,ssol_)$l_imp_r("ncba","sum",s)
    = 100 * (l_imp_r(ssol_,"sum",s) / l_imp_r("ncba","sum",s) - 1);

*       Export
d_exp_reg(r,i,s,ssol_) = l_exp_reg(r,i,s,ssol_) - l_exp_reg(r,i,s,"ncba") + eps;
d_exp_reg(r,i,"trn",ssol_) = l_exp_reg(r,i,"trn",ssol_) - l_exp_reg(r,i,"trn","ncba") + eps;
d_exp_reg(r,i,"sum",ssol_) = l_exp_reg(r,i,"sum",ssol_) - l_exp_reg(r,i,"sum","ncba") + eps;
d_exp_reg(r,i,r,ssol_) = 0;

pc_exp_reg(r,i,s,ssol_)$l_exp_reg(r,i,s,"ncba") = 100 * (l_exp_reg(r,i,s,ssol_) / l_exp_reg(r,i,s,"ncba") - 1) + eps;
pc_exp_reg(r,i,"trn",ssol_)$l_exp_reg(r,i,"trn","ncba") = 100 * (l_exp_reg(r,i,"trn",ssol_) / l_exp_reg(r,i,"trn","ncba") - 1) + eps;
pc_exp_reg(r,i,"sum",ssol_)$l_exp_reg(r,i,"sum","ncba") = 100 * (l_exp_reg(r,i,"sum",ssol_) / l_exp_reg(r,i,"sum","ncba") - 1) + eps;
pc_exp_reg(r,i,r,ssol_) = 0;

*       Value of export
pc_exp_v_reg(r,i,s,ssol_)$l_exp_v_reg(r,i,s,"ncba") = 100 * (l_exp_v_reg(r,i,s,ssol_) / l_exp_v_reg(r,i,s,"ncba") - 1) + eps;
pc_exp_v_reg(r,i,"trn",ssol_)$l_exp_v_reg(r,i,"trn","ncba") = 100 * (l_exp_v_reg(r,i,"trn",ssol_) / l_exp_v_reg(r,i,"trn","ncba") - 1) + eps;
pc_exp_v_reg(r,i,"sum",ssol_)$l_exp_v_reg(r,i,"sum","ncba") = 100 * (l_exp_v_reg(r,i,"sum",ssol_) / l_exp_v_reg(r,i,"sum","ncba") - 1) + eps;
pc_exp_v_reg(r,i,r,ssol_) = 0;

pc_exp_eite_c(r,ssol_)$l_exp_eite_c(r,"ncba") = 100 * (l_exp_eite_c(r,ssol_) / l_exp_eite_c(r,"ncba") - 1) + eps;
pc_imp_eite_c(r,ssol_)$l_imp_eite_c(r,"ncba") = 100 * (l_imp_eite_c(r,ssol_) / l_imp_eite_c(r,"ncba") - 1) + eps;

pc_exp_reg_jpn(i,s,ssol_)$l_exp_reg_jpn(i,s,"ncba") = 100 * (l_exp_reg_jpn(i,s,ssol_) / l_exp_reg_jpn(i,s,"ncba") - 1) + eps;
pc_exp_reg_jpn(i,"trn",ssol_)$l_exp_reg_jpn(i,"trn","ncba") = 100 * (l_exp_reg_jpn(i,"trn",ssol_) / l_exp_reg_jpn(i,"trn","ncba") - 1) + eps;
pc_exp_reg_jpn(i,"sum",ssol_)$l_exp_reg_jpn(i,"sum","ncba") = 100 * (l_exp_reg_jpn(i,"sum",ssol_) / l_exp_reg_jpn(i,"sum","ncba") - 1) + eps;

pc_exp_reg_chn(i,s,ssol_)$l_exp_reg_chn(i,s,"ncba") = 100 * (l_exp_reg_chn(i,s,ssol_) / l_exp_reg_chn(i,s,"ncba") - 1) + eps;
pc_exp_reg_chn(i,"trn",ssol_)$l_exp_reg_chn(i,"trn","ncba") = 100 * (l_exp_reg_chn(i,"trn",ssol_) / l_exp_reg_chn(i,"trn","ncba") - 1) + eps;
pc_exp_reg_chn(i,"sum",ssol_)$l_exp_reg_chn(i,"sum","ncba") = 100 * (l_exp_reg_chn(i,"sum",ssol_) / l_exp_reg_chn(i,"sum","ncba") - 1) + eps;

pc_exp_reg_ind(i,s,ssol_)$l_exp_reg_ind(i,s,"ncba") = 100 * (l_exp_reg_ind(i,s,ssol_) / l_exp_reg_ind(i,s,"ncba") - 1) + eps;
pc_exp_reg_ind(i,"trn",ssol_)$l_exp_reg_ind(i,"trn","ncba") = 100 * (l_exp_reg_ind(i,"trn",ssol_) / l_exp_reg_ind(i,"trn","ncba") - 1) + eps;
pc_exp_reg_ind(i,"sum",ssol_)$l_exp_reg_ind(i,"sum","ncba") = 100 * (l_exp_reg_ind(i,"sum",ssol_) / l_exp_reg_ind(i,"sum","ncba") - 1) + eps;

pc_exp_reg_kor(i,s,ssol_)$l_exp_reg_kor(i,s,"ncba") = 100 * (l_exp_reg_kor(i,s,ssol_) / l_exp_reg_kor(i,s,"ncba") - 1) + eps;
pc_exp_reg_kor(i,"trn",ssol_)$l_exp_reg_kor(i,"trn","ncba") = 100 * (l_exp_reg_kor(i,"trn",ssol_) / l_exp_reg_kor(i,"trn","ncba") - 1) + eps;
pc_exp_reg_kor(i,"sum",ssol_)$l_exp_reg_kor(i,"sum","ncba") = 100 * (l_exp_reg_kor(i,"sum",ssol_) / l_exp_reg_kor(i,"sum","ncba") - 1) + eps;

pc_exp_reg_ase(i,s,ssol_)$l_exp_reg_ase(i,s,"ncba") = 100 * (l_exp_reg_ase(i,s,ssol_) / l_exp_reg_ase(i,s,"ncba") - 1) + eps;
pc_exp_reg_ase(i,"trn",ssol_)$l_exp_reg_ase(i,"trn","ncba") = 100 * (l_exp_reg_ase(i,"trn",ssol_) / l_exp_reg_ase(i,"trn","ncba") - 1) + eps;
pc_exp_reg_ase(i,"sum",ssol_)$l_exp_reg_ase(i,"sum","ncba") = 100 * (l_exp_reg_ase(i,"sum",ssol_) / l_exp_reg_ase(i,"sum","ncba") - 1) + eps;

*       ------------------------------------------------------------
*       Sector

*       Output
d_y(r,i,ssol_)$l_y(r,i,"ncba") = l_y(r,i,ssol_) - l_y(r,i,"ncba");
d_y(reg_,i,ssol_)$l_y(reg_,i,"ncba") = l_y(reg_,i,ssol_) - l_y(reg_,i,"ncba");
d_y(r,ssec,ssol_)$l_y(r,ssec,"ncba") = l_y(r,ssec,ssol_) - l_y(r,ssec,"ncba");
d_y(reg_,ssec,ssol_)$l_y(reg_,ssec,"ncba") = l_y(reg_,ssec,ssol_) - l_y(reg_,ssec,"ncba");

pc_y(r,i,ssol_) = eps;
pc_y(r,ssec,ssol_) = eps;

pc_y(r,i,ssol_)$l_y(r,i,"ncba") = 100 * (l_y(r,i,ssol_) / l_y(r,i,"ncba") - 1) + eps;
pc_y(reg_,i,ssol_)$l_y(reg_,i,"ncba") = 100 * (l_y(reg_,i,ssol_) / l_y(reg_,i,"ncba") - 1) + eps;
pc_y(r,ssec,ssol_)$l_y(r,ssec,"ncba") = 100 * (l_y(r,ssec,ssol_) / l_y(r,ssec,"ncba") - 1) + eps;
pc_y(reg_,ssec,ssol_)$l_y(reg_,ssec,"ncba") = 100 * (l_y(reg_,ssec,ssol_) / l_y(reg_,ssec,"ncba") - 1) + eps;

pc_y_eite(r,ssol_)$l_y_eite(r,"ncba") = 100 * (l_y_eite(r,ssol_) / l_y_eite(r,"ncba") - 1) + eps;

*       VA by sector
d_va_s(r,i,ssol_)$l_va_s(r,i,"ncba") = l_va_s(r,i,ssol_) - l_va_s(r,i,"ncba");
d_va_s(r,ssec,ssol_)$l_va_s(r,ssec,"ncba") = l_va_s(r,ssec,ssol_) - l_va_s(r,ssec,"ncba");

pc_va_s(r,i,ssol_)$l_va_s(r,i,"ncba")
    = 100 * (l_va_s(r,i,ssol_) / l_va_s(r,i,"ncba") - 1) + eps;
pc_va_s(r,ssec,ssol_)$l_va_s(r,ssec,"ncba")
    = 100 * (l_va_s(r,ssec,ssol_) / l_va_s(r,ssec,"ncba") - 1) + eps;

*       ------------------------------------------------------------
*       Macroeconomic variables

*       Household actual income
d_inc(r,ssol_)$l_inc(r,"ncba") = l_inc(r,ssol_) - l_inc(r,"ncba");
d_inc(reg_,ssol_)$l_inc(reg_,"ncba") = l_inc(reg_,ssol_) - l_inc(reg_,"ncba");

pc_inc(r,ssol_)$l_inc(r,"ncba") = 100 * (l_inc(r,ssol_) / l_inc(r,"ncba") - 1);
pc_inc(reg_,ssol_)$l_inc(reg_,"ncba") = 100 * (l_inc(reg_,ssol_) / l_inc(reg_,"ncba") - 1);

*       Real GDP
d_gdp(r,ssol_)$l_gdp(r,"ncba") = l_gdp(r,ssol_) - l_gdp(r,"ncba");
d_gdp(reg_,ssol_)$l_gdp(reg_,"ncba") = l_gdp(reg_,ssol_) - l_gdp(reg_,"ncba");

pc_gdp(r,ssol_)$l_gdp(r,"ncba")
    = 100 * (l_gdp(r,ssol_) / l_gdp(r,"ncba") - 1);
pc_gdp(reg_,ssol_)$l_gdp(reg_,"ncba")
    = 100 * (l_gdp(reg_,ssol_) / l_gdp(reg_,"ncba") - 1);

*       Utility
pc_u(r,ssol_)$l_u("ncba",r)
    = 100 * (l_u(ssol_,r) / l_u("ncba",r) - 1);
pc_u(reg_,ssol_)$l_u("ncba",reg_)
    = 100 * (l_u(ssol_,reg_) / l_u("ncba",reg_) - 1);

*       Private consumption
pc_c(r,ssol_)$l_c("ncba",r)
    = 100 * (l_c(ssol_,r) / l_c("ncba",r) - 1);
pc_c(reg_,ssol_)$l_c("ncba",reg_)
    = 100 * (l_c(ssol_,reg_) / l_c("ncba",reg_) - 1);

*       Leisure
pc_lsr(r,ssol_)$l_lsr("ncba",r)
    = 100 * (l_lsr(ssol_,r) / l_lsr("ncba",r) - 1);
pc_lsr(reg_,ssol_)$l_lsr("ncba",reg_)
    = 100 * (l_lsr(ssol_,reg_) / l_lsr("ncba",reg_) - 1);

*       Total employment = sum of labor demand
pc_emp(r,ssol_)$l_emp("ncba",r)
    = 100 * (l_emp(ssol_,r) / l_emp("ncba",r) - 1);
pc_emp(reg_,ssol_)$l_emp("ncba",reg_)
    = 100 * (l_emp(ssol_,reg_) / l_emp("ncba",reg_) - 1);

*       Investment
pc_inv(r,ssol_)$l_inv("ncba",r)
    = 100 * (l_inv(ssol_,r) / l_inv("ncba",r) - 1);
pc_inv(reg_,ssol_)$l_inv("ncba",reg_)
    = 100 * (l_inv(ssol_,reg_) / l_inv("ncba",reg_) - 1);

*       Government consumption
pc_gov(r,ssol_)$l_gov("ncba",r)
    = 100 * (l_gov(ssol_,r) / l_gov("ncba",r) - 1);
pc_gov(reg_,ssol_)$l_gov("ncba",reg_)
    = 100 * (l_gov(ssol_,reg_) / l_gov("ncba",reg_) - 1);

*       Total export
pc_exp(r,ssol_)$l_exp("ncba",r)
    = 100 * (l_exp(ssol_,r) / l_exp("ncba",r) - 1);
pc_exp(reg_,ssol_)$l_exp("ncba",reg_)
    = 100 * (l_exp(ssol_,reg_) / l_exp("ncba",reg_) - 1);

*       Total import
pc_imp(r,ssol_)$l_imp("ncba",r)
    = 100 * (l_imp(ssol_,r) / l_imp("ncba",r) - 1);
pc_imp(reg_,ssol_)$l_imp("ncba",reg_)
    = 100 * (l_imp(ssol_,reg_) / l_imp("ncba",reg_) - 1);

*       ------------------------------------------------------------
*       Iron and steel

*       Output of iron and steel sector
d_y_i_s(r,ssol) = d_y(r,"i_s",ssol);
d_y_i_s("World",ssol) = d_y("World","i_s",ssol);

pc_y_i_s(r,ssol) = pc_y(r,"i_s",ssol);
pc_y_i_s("World",ssol) = pc_y("World","i_s",ssol);

d_va_i_s_s(r,ssol) = d_va_s(r,"i_s",ssol);

pc_va_i_s_s(r,ssol) = pc_va_s(r,"i_s",ssol);


*       Labor demand by sector
pc_ld(r,i,ssol_)$l_ld(r,i,"ncba")
    = 100 * (l_ld(r,i,ssol_) / l_ld(r,i,"ncba") - 1);
pc_ld(r,ssec,ssol_)$l_ld("ncba",ssec,r)
    = 100 * (l_ld(r,ssec,ssol_) / l_ld(r,ssec,"ncba") - 1);

*       Capital demand by sector
pc_kd(r,i,ssol_)$l_kd(r,i,"ncba")
    = 100 * (l_kd(r,i,ssol_) / l_kd(r,i,"ncba") - 1);
pc_kd("sum",r,ssol_)$l_kd(r,"sum","ncba")
    = 100 * (l_kd(r,"sum",ssol_) / l_kd(r,"sum","ncba") - 1);

*       Wage rate
pc_pl(r,ssol_)$l_pl("ncba",r) = 100 * (l_pl(ssol_,r) / l_pl("ncba",r) - 1);
*       Wage rate for producer
pc_plp(r,ssol_)$l_plp("ncba",r) = 100 * (l_plp(ssol_,r) / l_plp("ncba",r) - 1);
*       Rental price
pc_rk(r,ssol_)$l_rk("ncba",r) = 100 * (l_rk(ssol_,r) / l_rk("ncba",r) - 1);

*       Output price (producer price)
pc_pya(r,i,ssol_)$l_pya("ncba",i,r) = 100 * (l_pya(ssol_,i,r) / l_pya("ncba",i,r) - 1);
*       Output price (market price)
pc_pym(r,i,ssol_)$l_pym("ncba",i,r) = 100 * (l_pym(ssol_,i,r) / l_pym("ncba",i,r) - 1);

*       Output price (market price)
pc_pym_eite(r,i,ssol_)$l_pym_eite(r,i,"ncba") = 100 * (l_pym_eite(r,i,ssol_) / l_pym_eite(r,i,"ncba") - 1);
l_pym_eite(r,i,ssol_)$eite(i) = l_pym_eite(r,i,ssol_) + eps;

*       Labor income
pc_labinc(r,ssol_)$l_labinc("ncba",r) = 100 * (l_labinc(ssol_,r) / l_labinc("ncba",r) - 1);

*       Energy price (excl. CP payment)
pc_pene_ex(i,r,ssol_)$l_pene_ex("ncba",i,r) = 100 * (l_pene_ex(ssol_,i,r) / l_pene_ex("ncba",i,r) - 1);

*       % change in terms of trade
pc_tot(r,ssol_) = 100 * (l_tot(ssol_,r) / l_tot("ncba",r) - 1);

*       Labor demand by sector in Japan
pc_ld_jpn(i,ssol_) = pc_ld("jpn",i,ssol_);

*       Net export by commodity in Japan
pc_nexp_c_jpn(i,ssol_) = pc_nexp_c("jpn",i,ssol_);

*       Output in Japan
*       Labor demand by sector in Japan
pc_ld_jpn(ssec,ssol_) = pc_ld(ssec,"jpn",ssol_);

*       Net export by commodity in Japan
pc_nexp_c_jpn(ssec,ssol_) = pc_nexp_c("jpn",ssec,ssol_);

*       Output
pc_y_jpn(i,ssol_) = pc_y("jpn",i,ssol_) + eps;
pc_y_eur(i,ssol_) = pc_y("eur",i,ssol_) + eps;
pc_y_chn(i,ssol_) = pc_y("chn",i,ssol_) + eps;
pc_y_usa(i,ssol_) = pc_y("usa",i,ssol_) + eps;

pc_y_jpn(ssec,ssol_) = pc_y("jpn",ssec,ssol_) + eps;
pc_y_eur(ssec,ssol_) = pc_y("eur",ssec,ssol_) + eps;
pc_y_chn(ssec,ssol_) = pc_y("chn",ssec,ssol_) + eps;
pc_y_usa(ssec,ssol_) = pc_y("usa",ssec,ssol_) + eps;

d_eite_trade(r,i,"dom",ssol_)
    = l_eite_trade(r,i,"dom",ssol_) - l_eite_trade(r,i,"dom","ncba") + eps;
d_eite_trade(r,i,s,ssol_)
    = l_eite_trade(r,i,s,ssol_) - l_eite_trade(r,i,s,"ncba") + eps;
d_eite_trade(r,i,"sum",ssol_)
    = l_eite_trade(r,i,"sum",ssol_) - l_eite_trade(r,i,"sum","ncba") + eps;

pc_eite_trade(r,i,"dom",ssol_)$l_eite_trade(r,i,"dom","ncba")
    = 100 * (l_eite_trade(r,i,"dom",ssol_) / l_eite_trade(r,i,"dom","ncba") - 1) + eps;
pc_eite_trade(r,i,s,ssol_)$l_eite_trade(r,i,s,"ncba")
    = 100 * (l_eite_trade(r,i,s,ssol_) / l_eite_trade(r,i,s,"ncba") - 1) + eps;
pc_eite_trade(r,i,"sum",ssol_)$l_eite_trade(r,i,"sum","ncba")
    = 100 * (l_eite_trade(r,i,"sum",ssol_) / l_eite_trade(r,i,"sum","ncba") - 1) + eps;

l_eite_trade(r,i,"dom",ssol_)$eite(i) = l_eite_trade(r,i,"dom",ssol_) + eps;
l_eite_trade(r,i,s,ssol_)$eite(i) = l_eite_trade(r,i,s,ssol_) + eps;
l_eite_trade(r,i,"sum",ssol_)$eite(i) = l_eite_trade(r,i,"sum",ssol_) + eps;

d_eite_market(r,i,"dom",ssol_)
    = l_eite_market(r,i,"dom",ssol_) - l_eite_market(r,i,"dom","ncba") + eps;
d_eite_market(r,i,s,ssol_)
    = l_eite_market(r,i,s,ssol_) - l_eite_market(r,i,s,"ncba") + eps;
d_eite_market(r,i,"sum",ssol_)
    = l_eite_market(r,i,"sum",ssol_) - l_eite_market(r,i,"sum","ncba") + eps;

pc_eite_market(r,i,"dom",ssol_)$l_eite_market(r,i,"dom","ncba")
    = 100 * (l_eite_market(r,i,"dom",ssol_) / l_eite_market(r,i,"dom","ncba") - 1) + eps;
pc_eite_market(r,i,s,ssol_)$l_eite_market(r,i,s,"ncba")
    = 100 * (l_eite_market(r,i,s,ssol_) / l_eite_market(r,i,s,"ncba") - 1) + eps;
pc_eite_market(r,i,"sum",ssol_)$l_eite_market(r,i,"sum","ncba")
    = 100 * (l_eite_market(r,i,"sum",ssol_) / l_eite_market(r,i,"sum","ncba") - 1) + eps;

l_eite_market(r,i,"dom",ssol_)$eite(i) = l_eite_market(r,i,"dom",ssol_) + eps;
l_eite_market(r,i,s,ssol_)$eite(i) = l_eite_market(r,i,s,ssol_) + eps;
l_eite_market(r,i,"sum",ssol_)$eite(i) = l_eite_market(r,i,"sum",ssol_) + eps;

*       Summary indicator.
l_summary(r,"Carbon price ($/tCO2)",ssol) = l_pco2(ssol,r) + eps;
l_summary(r,"CO2 emissions (MtCO2)",ssol) = l_co2_t(r,ssol) + eps;
l_summary(r,"Leakage rate (%)",ssol) = l_leak_rate("Leakage_rate (%)",ssol);
l_summary(r,"Real GDP",ssol) = l_gdp(r,ssol) + eps;
l_summary(r,"Welfare",ssol) = l_u(ssol,r) + eps;
l_summary(r,"Consumption",ssol) = l_c(ssol,r) + eps;
l_summary(r,"Investment",ssol) = l_inv(ssol,r) + eps;
l_summary(r,"Gov. con.",ssol) = l_gov(ssol,r) + eps;
l_summary(r,"Export",ssol) = l_exp_c(r,"sum",ssol) + eps;
l_summary(r,"Import",ssol) = l_imp_c(r,"sum",ssol) + eps;
l_summary(r,"Terms of trade",ssol) = l_tot(ssol,r) + eps;
l_summary(r,"Employment",ssol) = l_emp(ssol,r) + eps;
l_summary(r,"Value of net CP rev. (bil$)",ssol) = l_vcprevn(ssol,r) + eps;
l_summary(r,"Value of CBAM imp. tariff (bil$)",ssol) = l_cbarev(ssol,"imp",r) + eps;
l_summary(r,"Value of CBAM exp. sub. (bil$)",ssol) = l_cbarev(ssol,"exp",r) + eps;

display l_summary;

*       Summary indicator.
pc_summary(r,"Carbon price ($/tCO2)",ssol_) = l_pco2(ssol_,r) + eps;
pc_summary(r,"CO2 emissions (MtCO2)",ssol_) = l_co2_t(r,ssol_) + eps;
pc_summary(r,"CO2 emissions (%)",ssol_) = pc_co2_t(r,ssol_) + eps;
pc_summary(r,"Leakage rate (%)",ssol_) = l_leak_rate("Leakage_rate (%)",ssol_);
pc_summary(r,"Real GDP (%)",ssol_) = pc_gdp(r,ssol_) + eps;
pc_summary(r,"Welfare (%)",ssol_) = pc_u(r,ssol_) + eps;
pc_summary(r,"Consumption (%)",ssol_) = pc_c(r,ssol_) + eps;
pc_summary(r,"Investment (%)",ssol_) = pc_inv(r,ssol_) + eps;
pc_summary(r,"Gov. con. (%)",ssol_) = pc_gov(r,ssol_) + eps;
pc_summary(r,"Export (%)",ssol_) = pc_exp_c(r,"sum",ssol_) + eps;
pc_summary(r,"Import (%)",ssol_) = pc_imp_c(r,"sum",ssol_) + eps;
*pc_summary(r,"Net export (%)",ssol_) = pc_nexp_c(r,"sum",ssol_) + eps;
pc_summary(r,"Terms of trade (%)",ssol_) = pc_tot(r,ssol_) + eps;
pc_summary(r,"Employment (%)",ssol_) = pc_emp(r,ssol_) + eps;
*pc_summary(r,"Labor tax rate (%)",ssol_) = l_labtax(ssol_,r) + eps;
pc_summary(r,"Output of EITE (%)",ssol_) = pc_y_eite(r,ssol_) + eps;
pc_summary(r,"Export of EITE (%)",ssol_) = pc_exp_eite_c(r,ssol_) + eps;
pc_summary(r,"Import of EITE (%)",ssol_) = pc_imp_eite_c(r,ssol_) + eps;
pc_summary(r,"Value of net CP rev. (bil$)",ssol_) = l_vcprevn(ssol_,r) + eps;
pc_summary(r,"Value of CBAM imp. tariff (bil$)",ssol_) = l_cbarev(ssol_,"imp",r) + eps;
pc_summary(r,"Value of CBAM exp. sub. (bil$)",ssol_) = l_cbarev(ssol_,"exp",r) + eps;
*pc_summary(r,"Value of net imp tax rev by CBA",ssol_) = l_cbarev(ssol_,"net",r) + eps;

pc_summary("World","Carbon price ($/tCO2)",ssol_) = eps;
pc_summary("World","CO2 emissions (MtCO2)",ssol_) = l_co2_t("World",ssol_) + eps;
pc_summary("World","CO2 emissions (%)",ssol_) = pc_co2_t("World",ssol_) + eps;
pc_summary("World","Leakage rate (%)",ssol_) = eps;
pc_summary("World","Real GDP (%)",ssol_) = pc_gdp("World",ssol_) + eps;
pc_summary("World","Welfare (%)",ssol_) = pc_u("World",ssol_) + eps;
pc_summary("World","Consumption (%)",ssol_) = pc_c("World",ssol_) + eps;
pc_summary("World","Investment (%)",ssol_) = pc_inv("World",ssol_) + eps;
pc_summary("World","Gov. con. (%)",ssol_) = pc_gov("World",ssol_) + eps;
pc_summary("World","Export (%)",ssol_) = pc_exp_c("World","sum",ssol_) + eps;
pc_summary("World","Import (%)",ssol_) = pc_imp_c("World","sum",ssol_) + eps;
*pc_summary("World","Net export (%)",ssol_) = pc_nexp_c("World","sum",ssol_) + eps;
pc_summary("World","Terms of trade (%)",ssol_) = pc_tot("World",ssol_) + eps;
pc_summary("World","Employment (%)",ssol_) = pc_emp("World",ssol_) + eps;
pc_summary("World","Unemployment rate (%)",ssol_) = eps;
*pc_summary("World","Labor tax rate (%)",ssol_) = l_labtax(ssol_,r) + eps;

pc_summary_cba(r,"imp",i,ssol_) = 100 * l_cbam(ssol_,i,"ave",r) + eps;
pc_summary_cba(r,"exp",i,ssol_) = - 100 * l_cbax(ssol_,i,r,"ave") + eps;

*       Summary indicator.
pc_summary_jpn("Carbon price ($/tCO2)",ssol_) = l_pco2(ssol_,"jpn") + eps;
pc_summary_jpn("CO2 emissions (MtCO2)",ssol_) = l_co2_t("jpn",ssol_) + eps;
pc_summary_jpn("CO2 emissions (%)",ssol_) = pc_co2_t("jpn",ssol_) + eps;
pc_summary_jpn("Leakage rate (%)",ssol_) = l_leak_rate("Leakage_rate (%)",ssol_);
pc_summary_jpn("Real GDP (%)",ssol_) = pc_gdp("jpn",ssol_) + eps;
pc_summary_jpn("Welfare (%)",ssol_) = pc_u("jpn",ssol_) + eps;
pc_summary_jpn("Consumption (%)",ssol_) = pc_c("jpn",ssol_) + eps;
pc_summary_jpn("Investment (%)",ssol_) = pc_inv("jpn",ssol_) + eps;
pc_summary_jpn("Gov. con. (%)",ssol_) = pc_gov("jpn",ssol_) + eps;
pc_summary_jpn("Export (%)",ssol_) = pc_exp_c("jpn","sum",ssol_) + eps;
pc_summary_jpn("Import (%)",ssol_) = pc_imp_c("jpn","sum",ssol_) + eps;
*pc_summary_jpn("Net export (%)",ssol_) = pc_nexp_c("jpn","sum",ssol_) + eps;
pc_summary_jpn("Terms of trade (%)",ssol_) = pc_tot("jpn",ssol_) + eps;
pc_summary_jpn("Employment (%)",ssol_) = pc_emp("jpn",ssol_) + eps;
*pc_summary_jpn("Labor tax rate (%)",ssol_) = l_labtax(ssol_,"jpn") + eps;
pc_summary_jpn("Output of EITE (%)",ssol_) = pc_y_eite("jpn",ssol_) + eps;
pc_summary_jpn("Export of EITE (%)",ssol_) = pc_exp_eite_c("jpn",ssol_) + eps;
pc_summary_jpn("Import of EITE (%)",ssol_) = pc_imp_eite_c("jpn",ssol_) + eps;
pc_summary_jpn("Value of net CP rev. (bil$)",ssol_) = l_vcprevn(ssol_,"jpn") + eps;
pc_summary_jpn("Value of CBAM imp. tariff (bil$)",ssol_) = l_cbarev(ssol_,"imp","jpn") + eps;
pc_summary_jpn("Value of CBAM exp. sub. (bil$)",ssol_) = l_cbarev(ssol_,"exp","jpn") + eps;
*pc_summary_jpn("Value of net imp tax rev by CBA",ssol_) = l_cbarev(ssol_,"net","jpn") + eps;

if(fl_debug,

    display "--- Check ---";
    display l_co2_t, d_co2_t, pc_co2_t, pc_co2_t_;
    display l_co2_use, d_co2_use, pc_co2_use;
    display l_co2_so, d_co2_so, pc_co2_so;
    display l_gdp, d_gdp, pc_gdp;
    display l_inc, d_inc, pc_inc;
    display l_u, pc_u;
    display l_y, d_y, pc_y;
    display pc_lsr;
    display l_va_s, d_va_s, pc_va_s;
    display l_exp_r, d_exp_r, pc_exp_r;
    display l_exp_eur, d_exp_eur, pc_exp_eur;
    display l_exp_eur_c, d_exp_eur_c, pc_exp_eur_c;
    display l_exp_reg, d_exp_reg, pc_exp_reg;
    display l_exp_reg_jpn, pc_exp_reg_jpn;
    display l_exp_reg_chn, pc_exp_reg_chn;
    display l_exp_reg_ind, pc_exp_reg_ind;
    display l_exp_reg_kor, pc_exp_reg_kor;
    display l_exp_reg_ase, pc_exp_reg_ase;
    display l_exp_c, d_exp_c, pc_exp_c;
    display l_imp_c, d_imp_c, pc_imp_c;
    display l_y_i_s, d_y_i_s, pc_y_i_s;
    display pc_y_eur, pc_y_jpn, pc_y_usa, pc_y_chn;
    display l_exp_i_s_c, d_exp_i_s_c, pc_exp_i_s_c;
    display l_imp_i_s_c, d_imp_i_s_c, pc_imp_i_s_c;
    display l_eite_trade, d_eite_trade, pc_eite_trade;
    display l_eite_market, d_eite_market, pc_eite_market;
    display l_pym, pc_pym, l_pym_eite;
    display l_cbam, l_cbax;
    display "--- Check ---";

);

display chk_objval, pc_summary, pc_summary_cba, pc_summary_jpn;
display chk_z_yafd_;

*       ----------------------------------------------------------------------
display "@ Export results to an excel file.";

$setglobal gdx_f .\results\%scen_name%_results.gdx

Execute_Unload '%gdx_f%', pc_summary, l_summary, l_leak_rate_reg, d_co2_leak_sec, d_co2_leak_reg,
    pc_nexp_c, pc_exp_reg, pc_exp_c, pc_imp_c, pc_exp_r, pc_exp_eur, pc_exp_eur_c, d_exp_eur_c,
    pc_y, d_y, pc_co2_use, d_co2_use, pc_u, pc_gdp, pc_summary_cba, l_gdp, l_inc, l_y, l_va_s,
    l_eite_trade, l_eite_market, l_pym_eite, pc_summary_jpn, l_co2_t, pc_co2_t;

$label end

execute 'del MRCGE.GEN';


* --------------------
* local variables:
* mode: gams
* fill-column: 100
* coding: utf-8-dos
* end:
