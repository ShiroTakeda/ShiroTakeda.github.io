
Time-stamp:	     <2025-10-10 10:29:47 st>
--------------------------------------------------------------------------

Program Description

--------------------

* Preparation

+ To run this program, in addition to the GAMS base module you will need two solvers: PATH and MPSGE.

+ The data used in the simulation (the file /data/cbam_18x17_gtap10ingams_gsd_3.gdx) is derived from
  GTAP 10 data, processed by the authors using GTAPinGAM
  (https://jgea.org/ojs/index.php/jgea/article/view/38 ).
+ The data is included solely for checking the simulation. If you intend to use GTAP data for your
  own simulations, please purchase the GTAP data.

* How to Run the Program

+ `cbam.gms` is the main program. Run this in GAMS Studio.
+ The computation results will be output to the \results\s_default_results.gdx file.
+ After running cbam.gms, execute `export_excel.bat` to export the contents of
  `s_default_results.gdx` to the `cba_summary_results.xlsx` file.



--------------------
Local Variables:
mode: org-mode
coding: utf-8
fill-column: 100
End:
