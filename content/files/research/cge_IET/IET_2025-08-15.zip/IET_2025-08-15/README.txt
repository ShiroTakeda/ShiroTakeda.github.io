
First-written:       <2010/06/10>
Time-stamp:	     <2019-08-21 17:22:28 st>
--------------------------------------------------------------------------

* Explanation

This archive includes the simulation programs used in the following paper:

Takeda, Shiro, Arimura, Toshi H. and Sugino, Makoto (2019) "Labor Market
Distortions and Welfare-Decreasing International Emissions Trading."
Environmental and Resource Economics, https://doi.org/10.1007/s10640-018-00317-4


** Requirement

To execute the simulation, you need to have the full license of the following
softwares:

+ GAMS base system
+ Solver PATH
+ Solver MPSGE


** How to run the simulation

*** If you want to run all scenarios including sensitivity analysis.

1) First, you need to include the folder of gams.exe in PATH envrionmental
   variable. For the details of PATH environtal variable, search it with google.

2) Click "run_multiple.bat" file. Then, the simulation will start.

3) After all simulations finish, click "export_excel.bat". Then the simulation
   results will be exported to "link_summary_results.xlsx" in the results
   folder. To export results to excel files, you must have MS excel.


*** Alternative approach.

If the above approach fails, run GAMS on "link_main.gms". This only solves main
scenario (not solve sensitivity analysis).




--------------------
Local Variables:
mode: org
coding: utf-8-dos
fill-column: 80
End:
run_multiple.bat


