
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2004/10/22>
Time-stamp:	       <2006-03-09 18:09:24 Shiro Takeda>

Version:
$Id: README.txt,v 1.2 2006/03/09 09:09:38 st Exp $

--------------------------------------------------------------------------

[Requirements]

To do the simulation below, GTAP version 5 and GTAPinGAMS version 5.3 need
to be installed in your computer properly.


[How to execute the simulation]

First, you need to create the dataset for the simulation.  For this,
execute create_data.bat.  After the dataset is created, execute
run_model.bat to run the model.


[Files included in the archive]

create_data.bat			Batch file for data aggregation.
run_model.bat			Batch file for executing simulation.

aspen5_takeda_test.map		Map file for data aggregation.
aspen5_takeda_test.set		Set file for data aggregation.

gtapaggr.gms			gtapaggr.gms file which is modified for
				the data aggregation in the paper.

weda2001_gdp_pop.dat		GDP and population data from EIA.

end_reg.gms			Main GAMS program.
end_reg_model.gms		GAMS code which defines the model.
end_reg_set.gms			GAMS code which defines sets.
end_reg_period_set.gms		GAMS code which defines sets for period.
end_reg_parameters.gms		GAMS code which defines parameters.

end_reg_initial.gms		GAMS code for setting initial value.
par_result_2010bau.gms		GAMS code for storing results temporarily.
exp_result_2010bau.gms		GAMS code for storing results temporarily.
imp_result_2010bau.gms		GAMS code for storing results temporarily.

end_reg_base.gms		GAMS program for soliving the base case.



--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
