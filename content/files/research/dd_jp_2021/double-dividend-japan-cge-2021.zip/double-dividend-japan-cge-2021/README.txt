
First-written:	<2021/02/14>
Time-stamp:	<2021-02-14 18:39:09 st>

--------------------------------------------------------------------------

* Explanation

This archive includes the simulation programs used in the following paper:

Takeda, S., Arimura, T.H. (2021) "A computable general equilibrium analysis of
environmental tax reform in Japan with a forward-looking dynamic model."
Sustainability Science. https://doi.org/10.1007/s11625-021-00903-4

** Requirement

To execute the simulation, you need to have the full license of the following
softwares:

+ GAMS base system
+ Solver PATH
+ Solver MPSGE


** How to run the simulation

*** If you want to run all scenarios including sensitivity analysis.

1) First, you need to include the folder of gams.exe in PATH envrionmental
   variable. For the details of PATH environtal variable, search it with google.

2) Click "run_all_scenarios.bat" file. Then, the simulation will start.

3) After all simulations finish, click "export_excel.bat". Then the simulation
   results will be exported to "results_summary.xlsx" in the "results"
   folder. To export results to excel files, you must have MS excel.


*** Alternative approach.

If the above approach fails, run GAMS on "main_program.gms". This only solves
main scenario (not solve sensitivity analysis).




--------------------
Local Variables:
mode: org
coding: utf-8
fill-column: 80
End:
