Filename:            README.txt
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2004/10/30>
Time-stamp:	       <2004-10-30 08:55:05 Shiro Takeda>

Version:
$Id: README.txt,v 1.1 2004/10/29 23:55:35 st Exp $

--------------------------------------------------------------------------

[Requirements]

The model is written as MCP format and you need to have solver PATH to
execute the simulation.


[How to execute the simulation]

Just run run_model.bat.  It calculates the effect of carbon regulation on
the welfare (the results listed in Table 8 of the paper).


[Files included in the archive]

run_model.bat			Execute this file to do the simulation.
dynamic_mcp_basic.gms		This code is called from run_model.bat.
dynamic_mcp.gms			The main GAMS code.
set_definition.gms		This defines sets.
dataset.dat			Data file.




--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
