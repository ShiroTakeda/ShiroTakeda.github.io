
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2005/08/04>
Time-stamp:	       <2005-08-04 17:25:38 Shiro Takeda>

Version:
$Id: README.txt,v 1.2 2005/08/04 08:25:43 st Exp $

--------------------------------------------------------------------------

Execute run_model.bat file.  Then, you will get the results in Table 7 of
the paper.



--------------------
Local Variables:
mode: indented-text
coding: ascii
fill-column: 74
End:
