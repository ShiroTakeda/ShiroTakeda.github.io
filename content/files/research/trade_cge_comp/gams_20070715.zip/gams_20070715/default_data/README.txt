Filename:            README.txt
Author:              Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/03/01>
Time-stamp:          <2007-07-02 11:40:09 Shiro Takeda>
Version:
$Id: README.txt,v 1.1 2006/07/29 14:01:43 st Exp $

--------------------------------------------------------------------------
[Requirement]

To run the simulation, you need the following programs and GAMS solver.

   + gams-f utility
   + gmsunzip.exe and har2gdx.exe
   + Solver PATH

   In addition, if you export outputs to excel files, then you need

   + xldump utility

Check if these programs are installed on your PC.  Needless to say, you
need to have GTAP 6 dataset.

[How to run the simulation]
                                
[1] First, you need to create the aggregated dataset from the original
GTAP 6 data.  The aggregation needs to be done by application GTAPAgg6
with "default_data.agg" as an gggregation scheme file.  If you accomplish
the aggregation, you get default_data.zip.  Then extract it into the
current directory (default_data directory).

[2] To run the simulation, execute "run_base_scenarios.bat".  This will
generate the results displayed in Table 3 and 4 in the paper.  The
percentage change in utility and sectoral output is reported by the
parameter "pc_u" and "pc_so" in the lst file.  In addition, the results
will be stored in excel files placed at results directory.  To run the
model by run_base_scenarios.bat, gams.exe must be included in
environmental variable PATH.  Similarly, to do the sensitivity analysis,
execute "run_sensitivity.bat".

Note that computation will require much time (maybe over an hour) although
it depends on ability of your PC.

For the details of the model implemented in this program, see the papers
distributed with this archive.  If you have any question about the
program, email me <zbc08106@park.zero.ad.jp>.


--------------------
Local Variables:
mode: indented-text
fill-column: 74
End:
