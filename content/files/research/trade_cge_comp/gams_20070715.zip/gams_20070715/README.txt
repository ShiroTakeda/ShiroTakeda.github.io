Filename:            README.txt
Author:		     Shiro Takeda
e-mail               <zbc08106@park.zero.ad.jp>
First-written:       <2006/10/18>
Time-stamp:	     <2007-07-15 17:11:42 Shiro Takeda>

$Id: README.txt,v 1.2 2006/11/22 04:25:16 st Exp $

[Note]

This archive includes programs for the simulation in the following paper:

Takeda, Shiro (2007) `Comparison of the Effects of Trade Liberalization under
Different Market Structures.'

For the details of the simulation, see README.txt file in the default_data
directory.


[Acknowledgment]

In writing this program, I have greatly benefited from programs of the Uruguay
round model created by Glenn W. Harrison, Thomas. F. Rutherford, David G. Tarr
and from GTAP6inGAMS package by Thomas. F. Rutherford.  I would like to
express acknowledgment to them.

The file "gtap6data.gms" is originally provided in GTAPinGAMS created by
Thomas F. Rutherford although I slightly modified its contents.

Uruguay round model is used in the following papers:

Harrison, Glenn W., Thomas F. Rutherford and David G. Tarr (1996) `Quantifying
the Uruguay Round,' in Will Martin and Alan L. Winters (eds.)  The Uruguay Round
and the Developing Economies, New York: Cambridge University Press, Chap. 7,
pp. 215--284.

Harrison, Glenn W., Thomas F. Rutherford and David G. Tarr (1997) `Quantifying
the Uruguay Round,' Economic Journal, Vol. 107, pp. 1405--1430, September.

In addition, programs of Uruguay Round model and GTAPinGAMS are available at the
following web sites:

http://dmsweb.badm.sc.edu/Glenn/ur_pub.htm

http://www.mpsge.org/


--------------------
Local Variables:
mode: indented-text
fill-column: 80
End:
